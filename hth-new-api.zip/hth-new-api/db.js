const Sequelize = require('sequelize');
const UsersModel = require('./rest/users/model');
const PropertiesModel = require('./rest/properties/model');
const UnitsModel = require('./rest/units/model');
/* const OtpHistoryModel = require('./rest/otps/model'); */
const TenantsModel = require('./rest/tenants/model');
const MaintenanceModel = require('./rest/maintenance/model');
const IssuesModel = require('./rest/issues/model');
const BillsModel = require('./rest/bills/model');
const NotificationModel = require('./rest/notifications/model')
const Op = Sequelize.Op;

const sequelize = new Sequelize(
    process.env.DB_NAME,
    process.env.DB_USER,
    process.env.DB_PASSWORD,
    {
        dialect: 'mysql',
        host: process.env.DB_HOST,
        port: process.env.DB_PORT,
        dialectOptions: {decimalNumbers: true},
        logging: false,
    }
);
const Users = UsersModel(sequelize, Sequelize);
const Properties = PropertiesModel(sequelize, Sequelize);
const Units = UnitsModel(sequelize, Sequelize);
/* const Otphistories = OtpHistoryModel(sequelize, Sequelize); */
const Tenants = TenantsModel(sequelize, Sequelize);
const Maintenance = MaintenanceModel(sequelize, Sequelize);
const Issues = IssuesModel(sequelize, Sequelize);
const Bills = BillsModel(sequelize, Sequelize);
const Notification = NotificationModel(sequelize, Sequelize);

const Models = {
    Op,
    Users,
    Properties,
    Units,
    /* Otphistories, */
    sequelize,
    Tenants,
    Maintenance,
    Issues,
    Bills,
    Notification
};
const connection = {};

module.exports = async () => {
    if (connection.isConnected) {
        console.log('=> Using existing connection.');
        return Models;
    }
    await sequelize.sync({ alter: true });
    await sequelize.authenticate();
    connection.isConnected = true;
    console.log('=> Created a new connection.');
    return Models;
};
