# AWS Lambda serverless API with MySQL
A quick and easy guide of how to hook up a single Serverless service with basic CRUD interaction.# homeathome-new-api-serverless
