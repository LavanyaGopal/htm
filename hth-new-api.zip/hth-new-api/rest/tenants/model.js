const bcrypt = require('bcryptjs');
module.exports = (sequelize, type) => {
    const Tenant = sequelize.define('Tenants', {
        id: {
            type: type.STRING,
            primaryKey: true,
        },
        user_id: {
            type: type.STRING,
            allowNull: false,
        },
        owner_id: {
            type: type.STRING,
            allowNull: false,
        },
        property_id: {
            type: type.STRING,
            allowNull: false,
        },
        unit_id: {
            type: type.STRING,
            allowNull: false,
        },
        joining_date: type.DATEONLY,
        vacated_date: type.DATEONLY,
        rent_billing: type.DATEONLY,
        rental_agreement: type.TEXT,
        id_proof: type.TEXT,
        unit_code: type.STRING,
        status: type.STRING, //Active, In Active
        is_deleted: type.STRING,
        createdBy: type.STRING,
        updatedBy: type.STRING,
        is_verified: type.BOOLEAN, // if yes show
    });

    return Tenant;
};
