const Validator = require('validatorjs');
const commonPassword = require('common-password-checker');
const {HTTPError} = require('../../utils/httpResp');
const connectToDatabase = require('../../db');

exports.validateCreateUser = (data) => {
    const rules = {
        name: 'required|min:4|max:64',
        email: 'email|min:4|max:64',
        phone: 'required',
        role: 'required',
        password: 'required|min:4|max:64',
    };
    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
    const hasUpperCase = /[A-Z]/.test(data.password);
    const hasLowerCase = /[a-z]/.test(data.password);
    const hasNumbers = /\d/.test(data.password);
    const hasNonalphas = /\W/.test(data.password);
    const hasTripple = /(.)\1\1/.test(data.password);


    if (!hasUpperCase && !hasLowerCase) throw new HTTPError(400, 'Password must contain one alphabetic character');
    if (!hasNumbers && !hasNonalphas) throw new HTTPError(400, 'Password must contain one numeric or special character');
    if (hasTripple) throw new HTTPError(400, 'Password must not have consecutive characters');
    if (commonPassword(data.password)) throw new HTTPError(400, 'Password must not be a common or easily guessable password');

    const validRoles = ['Tenant'];
    console.log(data.role);
    console.log(validRoles.includes(data.role));
    if (!validRoles.includes(data.role)) throw new HTTPError(400, 'Invalid role');
};

exports.validateTenanCreate = async (data) => {
    const rules = {
        id: 'required',
        joining_date: 'required',
        user_id: 'required',
        property_id: 'required',
        unit_id: 'required',
        unit_code: 'required',
        createdBy: 'required'
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        const {Users, Op} = await connectToDatabase();
        await Users.destroy({where: {id: data.user_id}});
        throw new HTTPError(400, validation.errors.all());
    }
}


exports.validateDropdown = (data) => {
    const rules = {
        unit_id: 'required',
        property_id: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
}
        
