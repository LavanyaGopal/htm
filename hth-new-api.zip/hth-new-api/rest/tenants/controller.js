const uuid = require('uuid');
const middy = require('@middy/core');
const doNotWaitForEmptyEventLoop = require('@middy/do-not-wait-for-empty-event-loop');
const connectToDatabase = require('../../db');
const {HTTPError} = require('../../utils/httpResp');
const authMiddleware = require('../../authMiddleware');
const {validateDropdown, validateCreate, validateCreateUser, validateTenanCreate} = require('./validation');
const jwt = require("jsonwebtoken");
const logging = require('slspress/lib/middleware/logging');


const create = async (event) => {
    try {
        let id;
        const {Tenants, Units, Properties, Users, Op} = await connectToDatabase();
        const input = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;

        const dataObject = Object.assign(input, {
            id: id || uuid.v4(),
            email: input.email || '',
            phone: input.phone || '',
            role: 'Tenant',
            password: input.password || 'Tenant@123!',
            is_verified: true
        });
        if (!dataObject.email && !dataObject.phone) throw new HTTPError(400, `Email or Phone no Required`);

        const unitsObj = await Units.findOne({
            where: {
                id: input.unit_id, is_deleted: {[Op.not]: true}, unit_status: 'Available'
            }, logging: console.log
        });
        if (!unitsObj) throw new HTTPError(400, `Invalid Unit ID : ${input.unit_id}`)

        const propertiesObj = await Properties.findOne({
            where: {id: input.property_id, is_deleted: {[Op.not]: true}}, raw: true
        });
        if (!propertiesObj) throw new HTTPError(404, `Properties for this ${input.property_id} was not found.`);

        let userObject = '';
        if (dataObject.email) {
            userObject = await Users.count({
                where: {
                    [Op.or]: [{email: dataObject.email}, {phone: dataObject.phone}], is_deleted: {[Op.not]: true}
                }, logging: console.log
            });
        } else {
            userObject = await Users.count({
                where: {phone: dataObject.phone, is_deleted: {[Op.not]: true}}, logging: console.log
            });
        }
        // if (userObject) throw new HTTPError(400, `User with email : ${dataObject.email} or phone : ${dataObject.phone} already exist`);
        let usersObj = undefined;
        if (!userObject) {
            validateCreateUser(dataObject);
            dataObject.is_temporary_password = true;
            dataObject.createdBy = event.user.id;
            usersObj = await Users.create(dataObject);
        } else {
            usersObj = await Users.findOne({
                where: {
                    [Op.or]: [{email: dataObject.email}, {phone: dataObject.phone}], is_deleted: {[Op.not]: true}
                }, logging: console.log
            });
        }

        if (!usersObj) throw new HTTPError(500, `could not create tenant details.`);

        const plaintext = usersObj.get({plain: true});

        unitsObj.unit_status = 'NotAvailable';
        await unitsObj.save();

        const ownerObj = await Users.findOne({
            where: {
                id: event.user.id, is_admin: true, role: 'Owner', is_deleted: {[Op.not]: true}
            }, logging: console.log, raw: true
        });
        let tenantObj = {
            id: uuid.v4(),
            joining_date: input.joining_date,
            user_id: plaintext.id,
            owner_id: event.user.id,
            property_id: propertiesObj.id,
            unit_id: unitsObj.id,
            unit_code: unitsObj.unit_code,
            createdBy: event.user.id,
            //status: 'Active'
        };
        validateTenanCreate(tenantObj);
        const newTenantObj = await Tenants.create(tenantObj);
        const tenantPlainText = newTenantObj.get({plain: true});
        tenantPlainText.name = plaintext.name;
        tenantPlainText.email = plaintext.email;
        tenantPlainText.phone = plaintext.phone;
        tenantPlainText.country_code = plaintext.country_code;
        tenantPlainText.role = plaintext.role;
        tenantPlainText.property_name = propertiesObj.property_name;
        tenantPlainText.unit_code = unitsObj.unit_code;
        tenantPlainText.unit_number = unitsObj.unit_number;
        tenantPlainText.unit_name = unitsObj.unit_name;
        tenantPlainText.unit_type = unitsObj.unit_type;
        tenantPlainText.rent = unitsObj.rent;
        tenantPlainText.owner_name = ownerObj.name;

        return {
            statusCode: 200, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify(tenantPlainText),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Could not create the Tenants deatails.'}),
        };
    }
}
const getAll = async (event) => {
    try {
        let header = event.headers;
        const {Tenants, Units, Properties, Users, Op} = await connectToDatabase();
        const query = event.queryStringParameters || {};
        if (header.offset) query.offset = parseInt(header.offset, 10);
        if (header.limit) query.limit = parseInt(header.limit, 10);
        if (query.where) query.where = JSON.parse(query.where);
        if (!query.where) {
            query.where = {};
        }
        query.where.is_deleted = {[Op.not]: true};
        query.where.owner_id = event.user.id;
        query.order = [['createdAt', 'DESC']];
        query.raw = true;

        const tenantsObj = await Tenants.findAll(query);
        for (let i = 0; i < tenantsObj.length; i++) {
            const usersObj = await Users.findOne({
                where: {id: tenantsObj[i].user_id, is_deleted: {[Op.not]: true}}, logging: console.log, raw: true
            });
            if (!usersObj) {
                tenantsObj.splice(i, 1);
                i--;
                continue;
            }
            const unitsObj = await Units.findOne({
                where: {
                    unit_code: tenantsObj[i].unit_code, is_deleted: {[Op.not]: true}
                }, logging: console.log, raw: true
            });
            if (!unitsObj) {
                tenantsObj.splice(i, 1);
                i--;
                continue;
            }
            const propertiesObj = await Properties.findOne({
                where: {
                    id: unitsObj.property_id, is_deleted: {[Op.not]: true}
                }, raw: true
            });
            if (!propertiesObj) {
                tenantsObj.splice(i, 1);
                i--;
                continue;
            }
            const ownerObj = await Users.findOne({
                where: {
                    id: tenantsObj[i].owner_id, is_admin: true, role: 'Owner', is_deleted: {[Op.not]: true}
                }, logging: console.log, raw: true
            });
            if (!ownerObj) {
                tenantsObj.splice(i, 1);
                i--;
                continue;
            }
            if (usersObj && unitsObj && propertiesObj && ownerObj) {
                tenantsObj[i].name = usersObj.name;
                tenantsObj[i].email = usersObj.email;
                tenantsObj[i].phone = usersObj.phone;
                tenantsObj[i].country_code = usersObj.country_code;
                tenantsObj[i].role = usersObj.role;
                tenantsObj[i].property_name = propertiesObj.property_name;
                tenantsObj[i].unit_code = unitsObj.unit_code;
                tenantsObj[i].unit_number = unitsObj.unit_number;
                tenantsObj[i].unit_name = unitsObj.unit_name;
                tenantsObj[i].unit_type = unitsObj.unit_type;
                tenantsObj[i].rent = unitsObj.rent;
                tenantsObj[i].owner_name = ownerObj.name;
            }
        }

        return {
            statusCode: 200, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify(tenantsObj),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Could not get Tenants Deatails.'}),
        };
    }
};
const getOne = async (event) => {
    try {
        const input = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        const pathParams = event.pathParameters;
        const {Tenants, Units, Properties, Users, Op} = await connectToDatabase();

        const tenantsObj = await Tenants.findOne({where: {id: pathParams.id, is_deleted: {[Op.not]: true}}, raw: true});
        if (!tenantsObj) throw new HTTPError(404, `Tenants with the ${pathParams.id} was not found`);

        const usersObj = await Users.findOne({
            where: {id: tenantsObj.user_id, is_deleted: {[Op.not]: true}}, raw: true, logging: console.log, raw: true
        });
        if (!usersObj) throw new HTTPError(404, `Users with the ${tenantsObj.user_id} was not found`);

        const unitsObj = await Units.findOne({
            where: {id: tenantsObj.unit_id, is_deleted: {[Op.not]: true}}, raw: true
        });
        if (!unitsObj) throw new HTTPError(404, `Units with the ${tenantsObj.unit_id} was not found`);

        const propertiesObj = await Properties.findOne({
            where: {
                id: tenantsObj.property_id, is_deleted: {[Op.not]: true}
            }, raw: true
        });
        if (!propertiesObj) throw new HTTPError(404, `Properties with the ${tenantsObj.property_id} was not found`);


        const ownerObj = await Users.findOne({
            where: {
                id: tenantsObj.owner_id, is_admin: true, role: 'Owner', is_deleted: {[Op.not]: true}
            }, logging: console.log, raw: true
        });
        if (!ownerObj) throw new HTTPError(404, `Owner details with the ${tenantsObj.owner_id} was not found`);

        tenantsObj.name = usersObj.name;
        tenantsObj.email = usersObj.email;
        tenantsObj.phone = usersObj.phone;
        tenantsObj.country_code = usersObj.country_code;
        tenantsObj.role = usersObj.role;
        tenantsObj.property_name = propertiesObj.property_name;
        tenantsObj.unit_code = unitsObj.unit_code;
        tenantsObj.unit_number = unitsObj.unit_number;
        tenantsObj.unit_name = unitsObj.unit_name;
        tenantsObj.unit_type = unitsObj.unit_type;
        tenantsObj.rent = unitsObj.rent;
        tenantsObj.owner_name = ownerObj.name;
        return {
            statusCode: 200, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify(tenantsObj),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Could not get Tenants Deatails.'}),
        };
    }
};
const update = async (event) => {
    try {
        const input = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        const pathParams = event.pathParameters;
        const {Tenants, Units, Properties, Op, Users} = await connectToDatabase();
        const tenantsObj = await Tenants.findOne({where: {id: pathParams.id, is_deleted: {[Op.not]: true}}});
        if (!tenantsObj) throw new HTTPError(404, `Tenants with the ${pathParams.id} was not found`);

        const userUpdateColumn = {
            name: input.name, email: input.email, phone: input.phone, updatedBy: event.user.id
        };
        await Users.update(userUpdateColumn, {where: {id: tenantsObj.user_id}});

        const tenantUpdateColumn = {
            joining_date: input.joining_date, updatedBy: event.user.id,
        }
        if (input.vacated_date) {
            tenantUpdateColumn.vacated_date = input.vacated_date;
            tenantUpdateColumn.status = 'InActive';
        }
        if(input.is_verified){
            tenantUpdateColumn.is_verified = input.is_verified;
        }
        await Tenants.update(tenantUpdateColumn, {where: {id: tenantsObj.id}});
        if (input.vacated_date) {
            const updateUnits = await Units.findOne({
                where: {
                    id: tenantsObj.unit_id, property_id: tenantsObj.property_id, is_deleted: {[Op.not]: true}
                }
            });
            updateUnits.unit_status = 'Available';
            await updateUnits.save();
        }

        const usersObj = await Users.findOne({where: {id: tenantsObj.user_id, is_deleted: {[Op.not]: true}}});
        const unitsObj = await Units.findOne({
            where: {id: tenantsObj.unit_id, is_deleted: {[Op.not]: true}}, raw: true
        });
        const propertiesObj = await Properties.findOne({
            where: {
                id: tenantsObj.property_id, is_deleted: {[Op.not]: true}
            }, raw: true
        });
        const tenantsUpdatedDeatails = await Tenants.findOne({
            where: {id: tenantsObj.id, is_deleted: {[Op.not]: true}}, raw: true
        });
        const ownerObj = await Users.findOne({
            where: {
                id: tenantsObj.owner_id, is_admin: true, role: 'Owner', is_deleted: {[Op.not]: true}
            }, raw: true
        });

        tenantsUpdatedDeatails.name = usersObj.name;
        tenantsUpdatedDeatails.email = usersObj.email;
        tenantsUpdatedDeatails.phone = usersObj.phone;
        tenantsUpdatedDeatails.country_code = usersObj.country_code;
        tenantsUpdatedDeatails.role = usersObj.role;
        tenantsUpdatedDeatails.property_name = propertiesObj.property_name;
        tenantsUpdatedDeatails.unit_code = unitsObj.unit_code;
        tenantsUpdatedDeatails.unit_number = unitsObj.unit_number;
        tenantsUpdatedDeatails.unit_name = unitsObj.unit_name;
        tenantsUpdatedDeatails.unit_type = unitsObj.unit_type;
        tenantsUpdatedDeatails.rent = unitsObj.rent;
        tenantsUpdatedDeatails.owner_name = ownerObj.name;

        return {
            statusCode: 200, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify(tenantsUpdatedDeatails),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Could not update the Tenants Deatails.'}),
        };
    }
};
const destroy = async (event) => {
    try {
        const pathParams = event.pathParameters;
        const {Tenants, Units, Properties, Op, Users} = await connectToDatabase();
        const tenantsObj = await Tenants.findOne({where: {id: pathParams.id, is_deleted: {[Op.not]: true}}});
        const usersObj = await Users.findOne({where: {id: tenantsObj.user_id, is_deleted: {[Op.not]: true}}});
        const unitsObj = await Units.findOne({
            where: {
                id: tenantsObj.unit_id,
                property_id: tenantsObj.property_id,
                unit_status: 'NotAvailable',
                is_deleted: {[Op.not]: true}
            }
        });

        if (!usersObj) throw new HTTPError(404, `Users for this Tenant was not found`);
        if (!tenantsObj) throw new HTTPError(404, `Units for this ${tenantsObj.id} was not found`);
        usersObj.is_deleted = true;
        usersObj.updatedBy = event.user.id;
        await usersObj.save();
        tenantsObj.is_deleted = true;
        tenantsObj.updatedBy = event.user.id;
        await tenantsObj.save();

        unitsObj.unit_status = 'Available';
        await unitsObj.save();

        return {
            statusCode: 200, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({
                status: 'ok', message: 'Successfully Tenants Data removed',
            }),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Could not Delete Tenants Deatails.'}),
        };
    }
};
const dropdown = async (event) => {
    try {
        let header = event.headers;
        const {Tenants, Units, Properties, Users, Op} = await connectToDatabase();
        const input = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        const query = event.queryStringParameters || {};
        if (header.offset) query.offset = parseInt(header.offset, 10);
        if (header.limit) query.limit = parseInt(header.limit, 10);
        if (query.where) query.where = JSON.parse(query.where);
        if (!query.where) {
            query.where = {};
        }

        query.where.is_deleted = {[Op.not]: true};
        query.order = [['createdAt', 'DESC']];
        query.raw = true;
        const tenantsObj = await Tenants.findAll(query);
        for (let i = 0; i < tenantsObj.length; i++) {
            const usersObj = await Users.findOne({
                where: {id: tenantsObj[i].user_id, is_deleted: {[Op.not]: true}}, raw: true
            });
            if (!usersObj) {
                tenantsObj.splice(i, 1);
                i--;
                continue;
            }
            const unitsObj = await Units.findOne({
                where: {id: tenantsObj[i].unit_id, is_deleted: {[Op.not]: true}}, raw: true
            });
            if (!unitsObj) {
                tenantsObj.splice(i, 1);
                i--;
                continue;
            }
            const propertiesObj = await Properties.findOne({
                where: {
                    id: tenantsObj[i].property_id, is_deleted: {[Op.not]: true}
                }, raw: true
            });
            if (!propertiesObj) {
                tenantsObj.splice(i, 1);
                i--;
                continue;
            }
            const createdUserObj = await Users.findOne({
                where: {
                    id: tenantsObj[i].createdBy, is_deleted: {[Op.not]: true}
                }, raw: true
            });
            if (!createdUserObj) {
                tenantsObj.splice(i, 1);
                i--;
                continue;
            }
            if (usersObj && unitsObj && propertiesObj) {
                tenantsObj[i].name = usersObj.name;
                tenantsObj[i].email = usersObj.email;
                tenantsObj[i].phone = usersObj.phone;
                tenantsObj[i].country_code = usersObj.country_code;
                tenantsObj[i].role = usersObj.role;
                tenantsObj[i].property_name = propertiesObj.property_name;
                tenantsObj[i].unit_code = unitsObj.unit_code;
                tenantsObj[i].unit_number = unitsObj.unit_number;
                tenantsObj[i].unit_name = unitsObj.unit_name;
                tenantsObj[i].unit_type = unitsObj.unit_type;
                tenantsObj[i].rent = unitsObj.rent;
                tenantsObj[i].created_by = createdUserObj.name;
            }
        }
        return {
            statusCode: 200, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify(tenantsObj),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Could not Fetch Tenant Deatails.'}),
        };
    }
}

const getTenantUnitsDetails = async (event) => {
    try {
        const {Tenants, Units, Properties, Users, Op} = await connectToDatabase();

        const usersObj = await Users.findOne({
            where: {id: event.user.id, role: 'Tenant', is_deleted: {[Op.not]: true}},
            raw: true
        });
        const tenantsObj = await Tenants.findAll({
            where: {
                user_id: usersObj.id,
                //status: 'Active',
                is_deleted: {[Op.not]: true}
            }, raw: true
        });

        for (let i = 0; i < tenantsObj.length; i++) {
            const unitsObj = await Units.findOne({
                where: {id: tenantsObj[i].unit_id, is_deleted: {[Op.not]: true}}, raw: true
            });
            if (!unitsObj) {
                tenantsObj.splice(i, 1);
                i--;
                continue;
            }
            const propertiesObj = await Properties.findOne({
                where: {
                    id: tenantsObj[i].property_id, is_deleted: {[Op.not]: true}
                }, raw: true
            });
            if (!propertiesObj) {
                tenantsObj.splice(i, 1);
                i--;
                continue;
            }
            const createdUserObj = await Users.findOne({
                where: {
                    id: tenantsObj[i].createdBy, is_deleted: {[Op.not]: true}
                }, raw: true
            });
            if (!createdUserObj) {
                tenantsObj.splice(i, 1);
                i--;
                continue;
            }
            if (usersObj && unitsObj && propertiesObj) {
                tenantsObj[i].name = usersObj.name;
                tenantsObj[i].email = usersObj.email;
                tenantsObj[i].phone = usersObj.phone;
                tenantsObj[i].country_code = usersObj.country_code;
                tenantsObj[i].role = usersObj.role;
                tenantsObj[i].property_name = propertiesObj.property_name;
                tenantsObj[i].unit_code = unitsObj.unit_code;
                tenantsObj[i].unit_number = unitsObj.unit_number;
                tenantsObj[i].unit_name = unitsObj.unit_name;
                tenantsObj[i].unit_type = unitsObj.unit_type;
                tenantsObj[i].rent = unitsObj.rent;
                tenantsObj[i].created_by = createdUserObj.name;
            }
        }

        return {
            statusCode: 200, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify(tenantsObj),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Could not get the Tenants unit deatails.'}),
        };
    }
}

const getTenantUnitsDetailswithUnitCode = async (event) => {
    try {
        const {Tenants, Units, Properties, Users, Op} = await connectToDatabase();
        console.log(event);
        const queryParams = event.pathParameters || event.queryStringParameters || {};

        const unit_code = queryParams.unit_code;

        const searchUnitCode = await Units.findOne({
            where: {unit_code: unit_code, is_deleted: {[Op.not]: true}}, raw: true
        });
        console.log(searchUnitCode);
        if(!searchUnitCode) throw new HTTPError(404, `Invalid unit code ${unit_code}`);
        console.log(searchUnitCode);
        const property_id = searchUnitCode.property_id;
        const unit_id = searchUnitCode.id;

        const usersObj = await Users.findOne({
            where: {id: event.user.id, role: 'Tenant', is_deleted: {[Op.not]: true}},
            raw: true
        });
        if(!usersObj) throw new HTTPError(404, `Invalid user details.`
        );
        
        const tenantsObj = await Tenants.findOne({
            
            where: {
                user_id: usersObj.id,
                property_id,
                unit_id,
                //status: 'Active',
                is_deleted: {[Op.not]: true}
            }, raw: true,
        
            logging:console.log
        });


        if (!tenantsObj) throw new HTTPError(500, `Tenants details with Property ${property_id} with unit ${unit_id} was not found`);

        const unitsObj = await Units.findOne({
            where: {id: tenantsObj.unit_id, is_deleted: {[Op.not]: true}}, raw: true
        });

        const propertiesObj = await Properties.findOne({
            where: {
                id: tenantsObj.property_id, is_deleted: {[Op.not]: true}
            }, raw: true
        });

        const createdUserObj = await Users.findOne({
            where: {
                id: tenantsObj.createdBy, is_deleted: {[Op.not]: true}
            }, raw: true
        });

        usersObj.tenant_id = tenantsObj.id;
        usersObj.owner_id = tenantsObj.owner_id;
        usersObj.property_id = tenantsObj.property_id;
        usersObj.unit_id = tenantsObj.unit_id;
        usersObj.joining_date = tenantsObj.joining_date
        usersObj.vacated_date = tenantsObj.vacated_date
        usersObj.unit_code = tenantsObj.unit_code
        usersObj.status = tenantsObj.status
        usersObj.is_deleted = tenantsObj.is_deleted

        usersObj.property_name = propertiesObj.property_name;
        usersObj.unit_code = unitsObj.unit_code;
        usersObj.unit_number = unitsObj.unit_number;
        usersObj.unit_name = unitsObj.unit_name;
        usersObj.unit_type = unitsObj.unit_type;
        usersObj.rent = unitsObj.rent;
        usersObj.created_by = createdUserObj.name;

        //const tokenUser = usersObj;
        const token = jwt.sign(usersObj, process.env.JWT_SECRET, {expiresIn: process.env.JWT_EXPIRATION_TIME,});
        const responseData = {user: {name: usersObj.name, role: usersObj.role,}};
        responseData.property_id = tenantsObj.property_id;
        responseData.property_name = propertiesObj.property_name;
        responseData.unit_id = unitsObj.id;
        responseData.unit_name = unitsObj.unit_name;
        responseData.authToken = `JWT ${token}`;
        

        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({status: "ok", message: "success", auth_response: responseData}),
        };

    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Could not get the Tenants unit deatails.'}),
        };
    }
}

const generateNewTokenIdwithPropertyDetails = async (event) => {
    try {
        const {Tenants, Units, Properties, Users, Op} = await connectToDatabase();

        const queryParams = event.pathParameters || event.queryStringParameters || {};

        const property_id = queryParams.property_id;
        const unit_id = queryParams.unit_id;

        const usersObj = await Users.findOne({
            where: {id: event.user.id, role: 'Tenant', is_deleted: {[Op.not]: true}},
            raw: true
        });
        const tenantsObj = await Tenants.findOne({
            where: {
                user_id: usersObj.id,
                property_id,
                unit_id,
                //status: 'Active',
                is_deleted: {[Op.not]: true}
            }, raw: true
        });

        if (!tenantsObj) throw new HTTPError(500, `Tenants details with Property ${property_id} with unit ${unit_id} was not found`);

        const unitsObj = await Units.findOne({
            where: {id: tenantsObj.unit_id, is_deleted: {[Op.not]: true}}, raw: true
        });

        const propertiesObj = await Properties.findOne({
            where: {
                id: tenantsObj.property_id, is_deleted: {[Op.not]: true}
            }, raw: true
        });

        const createdUserObj = await Users.findOne({
            where: {
                id: tenantsObj.createdBy, is_deleted: {[Op.not]: true}
            }, raw: true
        });

        usersObj.tenant_id = tenantsObj.id;
        usersObj.owner_id = tenantsObj.owner_id;
        usersObj.property_id = tenantsObj.property_id;
        usersObj.unit_id = tenantsObj.unit_id;
        usersObj.joining_date = tenantsObj.joining_date
        usersObj.vacated_date = tenantsObj.vacated_date
        usersObj.unit_code = tenantsObj.unit_code
        usersObj.status = tenantsObj.status
        usersObj.is_deleted = tenantsObj.is_deleted

        usersObj.property_name = propertiesObj.property_name;
        usersObj.unit_code = unitsObj.unit_code;
        usersObj.unit_number = unitsObj.unit_number;
        usersObj.unit_name = unitsObj.unit_name;
        usersObj.unit_type = unitsObj.unit_type;
        usersObj.rent = unitsObj.rent;
        usersObj.created_by = createdUserObj.name;

        //const tokenUser = usersObj;
        const token = jwt.sign(usersObj, process.env.JWT_SECRET, {expiresIn: process.env.JWT_EXPIRATION_TIME,});
        const responseData = {user: {name: usersObj.name, role: usersObj.role,}};
        responseData.authToken = `JWT ${token}`;

        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({status: "ok", message: "success", auth_response: responseData}),
        };

    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Could not get the Tenants unit deatails.'}),
        };
    }
}
module.exports.create = middy(create).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.getAll = getAll;
module.exports.getOne = middy(getOne).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.update = middy(update).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.destroy = middy(destroy).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.getTenantUnitsDetails = middy(getTenantUnitsDetails).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.dropdown = dropdown;
module.exports.generateNewTokenIdwithPropertyDetails = middy(generateNewTokenIdwithPropertyDetails).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.getTenantUnitsDetailswithUnitCode = middy(getTenantUnitsDetailswithUnitCode).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
