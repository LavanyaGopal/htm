const {generateRandomString} = require('../../utils/randomStringGenerator');
const AWS = require('aws-sdk');
const s3 = new AWS.S3();

const getUploadURL = async (input) => {
    let fileExtention = '';
    let newfilename = '';
    if (input.file_name) {
        const filterarr = input.file_name.split('.');
        fileExtention = `.` + filterarr.pop();
        newfilename = filterarr.join("_");
        const randomCode = generateRandomString(8);
        newfilename = newfilename + '_' + randomCode + fileExtention;
    }
    if(input?.id) newfilename = `${input.id}/${newfilename}`;

    const s3Params = {
        Bucket: process.env.S3_BUCKET_FOR_SETTINGS,
        Key: newfilename,
        ContentType: input.content_type,
        ACL: 'public-read',
    };

    return new Promise((resolve, reject) => {
        const uploadURL = s3.getSignedUrl('putObject', s3Params);
        resolve({
            uploadURL,
            s3_file_key: s3Params.Key,
            public_url: `https://${s3Params.Bucket}.s3.amazonaws.com/${s3Params.Key}`,
        });
    });
};

/* Upload Profile Image */

const userUploadFile = async (event) => {
    try {
        const input = event.body;
        if(event?.user?.id) input.id = event.user.id;
        const uploadURLObject = await getUploadURL(input);
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({
                uploadURL: uploadURLObject.uploadURL,
                s3_key: uploadURLObject.s3_file_key,
                public_url: uploadURLObject.public_url,
            }),
        };
    } catch (err) {
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not upload the legalForms.'}),
        };
    }
};

module.exports.userUploadFile = userUploadFile;