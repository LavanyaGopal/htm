const Validator = require('validatorjs');
const {HTTPError} = require('../../utils/httpResp');


exports.validateCreateBills = function (data) {
    const rules = {
        property_id: 'required',
        unit_id: 'required',
        user_id: 'required',
        bill_type: 'required',
        amount: 'required',
        tenant_id: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
};
exports.validateGetOne = function (data) {
    const rules = {
        id: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
};
exports.validateUpdate = function (data) {
    const rules = {
        id: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
};
exports.validateDestroy = function (data) {
    const rules = {
        id: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
};

