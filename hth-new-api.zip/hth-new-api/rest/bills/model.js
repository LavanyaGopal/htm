module.exports = (sequelize, type) => sequelize.define('Bills', {
    id: {
        type: type.STRING,
        primaryKey: true,
    },
    user_id: {
        type: type.STRING,
        allowNull: false,
    },
    property_id: {
        type: type.STRING,
        allowNull: false,
    },
    unit_id: {
        type: type.STRING,
        allowNull: false,
    },
    tenant_id: {
        type: type.STRING,
        allowNull: false,
    },
    bill_type: type.STRING,
    amount: type.STRING,
    due_date: type.DATEONLY, //yyyy-mm-dd
    status: type.STRING,//Pending,Completed
    payment_date: type.DATEONLY,
    proof_of_payment: type.TEXT,
    owner_receipt: type.TEXT,
    is_deleted: type.BOOLEAN,
    createdBy: type.STRING,
    updatedBy: type.STRING,
});