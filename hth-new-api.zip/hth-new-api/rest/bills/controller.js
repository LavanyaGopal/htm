const uuid = require('uuid');
const middy = require('@middy/core');
const doNotWaitForEmptyEventLoop = require('@middy/do-not-wait-for-empty-event-loop');
const connectToDatabase = require('../../db');
const {HTTPError} = require('../../utils/httpResp');
const authMiddleware = require('../../authMiddleware');
const {validateCreateBills, validateGetOne, validateUpdate, validateDestroy} = require('./validation');
const {generateRandomString} = require('../../utils/randomStringGenerator');
const AWS = require('aws-sdk');
const s3 = new AWS.S3();
const {pushNotification} = require('../../utils/sendPushNotification');
const {NotificationStamp} = require('../../utils/timeStamp');

const create = async (event) => {
    try {
        const {Bills, Users, Tenants, Properties, Units, Op, Notification} = await connectToDatabase();
        let id;
        const input = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        const dataObject = Object.assign(input, {id: id || uuid.v4(), user_id: input.user_id || event.user.id});
        validateCreateBills(dataObject);
        dataObject.status = 'not-paid';
        dataObject.createdBy = event.user.id;
        const billsObj = await Bills.create(dataObject);
        const plainText = billsObj.get({plain: true});

        const ownerInfo = await Users.findOne({
            where: {id: plainText.user_id, is_deleted: {[Op.not]: true}},
            raw: true
        });
        const propertiesObj = await Properties.findOne({
            where: {
                id: plainText.property_id,
                is_deleted: {[Op.not]: true}
            }, raw: true
        });
        plainText.property_name = propertiesObj.property_name;
        const unitsObj = await Units.findOne({where: {id: plainText.unit_id, is_deleted: {[Op.not]: true}}, raw: true});
        plainText.unit_name = unitsObj.unit_name;
        const tenant_table_Obj = await Tenants.findOne({
            where: {id: plainText.tenant_id, is_deleted: {[Op.not]: true}},
            logging: console.log,
            raw: true
        });
        const tenant_user_obj = await Users.findOne({
            where: {
                id: tenant_table_Obj.user_id,
                role: 'Tenant',
                is_deleted: {[Op.not]: true}
            }, raw: true
        });
        plainText.tenant_name = tenant_user_obj.name;

        const ownernotification = {
            id: uuid.v4(), user_id: event.user.id, user_role: event.user.role, createdBy: event.user.id,
        };

        const OwnerAndroidID = ownerInfo.device_token || '';
        const ownerTitle = `${propertiesObj.property_name}: You have created a Bill for the unit ${unitsObj.unit_name}`;
        const ownerMessageBody = `Bill is created for this month. Please pay before the due date. Thank you.`;

        ownernotification.notification_type = 'Bill';
        ownernotification.notification_type_id = plainText.id;
        ownernotification.property_name = propertiesObj.property_name;
        ownernotification.unit_name = unitsObj.unit_name;
        ownernotification.title = ownerTitle;
        ownernotification.message = ownerMessageBody;
        if (OwnerAndroidID) {
            ownernotification.device_token = OwnerAndroidID;
        }

        await Notification.create(ownernotification);

        if (ownerInfo.device_token) {
            await pushNotification(OwnerAndroidID, ownerTitle, ownerMessageBody);
        }

        const tenantNotification = {
            id: uuid.v4(), user_id: tenant_user_obj.id, user_role: tenant_user_obj.role, createdBy: event.user.id,
        };

        const TenantAndroidID = tenant_user_obj.device_token || '';
        const tenantTitle = `${propertiesObj.property_name}: Owner has sent you a Bill for the unit ${unitsObj.unit_name}`;
        const tenantMessageBody = `Bill is created for this month. Please pay before the due date. Thank you.`;

        tenantNotification.notification_type = 'Bill';
        tenantNotification.notification_type_id = plainText.id;
        tenantNotification.property_name = propertiesObj.property_name;
        tenantNotification.unit_name = unitsObj.unit_name;
        tenantNotification.title = tenantTitle;
        tenantNotification.message = tenantMessageBody;
        if (TenantAndroidID) {
            tenantNotification.device_token = TenantAndroidID;
        }

        await Notification.create(tenantNotification);

        if (tenant_user_obj.device_token) {
            await pushNotification(TenantAndroidID, tenantTitle, tenantMessageBody);
        }

        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify(plainText),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not create the Bill Deatails.'}),
        };
    }
};
const getOne = async (event) => {
    try {
        const {Bills, Users, Tenants, Properties, Units, Op} = await connectToDatabase();
        const pathParams = event.pathParameters || event.queryStringParameters;
        const login_user_info = event.user;
        if(login_user_info && login_user_info.role == 'Tenant' && !login_user_info.property_id && !login_user_info.unit_id) 
        {
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'text/plain',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': true
                },
                body: JSON.stringify([]),
            };
        }
        validateGetOne(pathParams);
        const billsObj = await Bills.findOne({where: {id: pathParams.id, is_deleted: {[Op.not]: true}}, raw: true});
        if (!billsObj) throw new HTTPError(404, `Bills with id: ${pathParams.id} was not found`);
        const propertiesObj = await Properties.findOne({
            where: {id: billsObj.property_id, is_deleted: {[Op.not]: true}},
            raw: true
        });
        billsObj.property_name = propertiesObj.property_name;
        const unitsObj = await Units.findOne({where: {id: billsObj.unit_id, is_deleted: {[Op.not]: true}}, raw: true});
        billsObj.unit_name = unitsObj.unit_name;
        const tenant_table_Obj = await Tenants.findOne({
            where: {id: billsObj.tenant_id, is_deleted: {[Op.not]: true}},
            raw: true
        });
        const tenant_user_obj = await Users.findOne({
            where: {
                id: tenant_table_Obj.user_id,
                role: 'Tenant',
                is_deleted: {[Op.not]: true}
            }, raw: true
        });
        billsObj.tenant_name = tenant_user_obj.name;
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify(billsObj),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not fetch the  Bills.'}),
        };
    }
};
const getAll = async (event) => {
    try {
        const {Bills, Users, Tenants, Properties, Units, Op} = await connectToDatabase();
        let user_id = event.user.id;
        const login_user_info = event.user;
        if(login_user_info && login_user_info.role == 'Tenant' && !login_user_info.property_id && !login_user_info.unit_id) 
        {
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'text/plain',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': true
                },
                body: JSON.stringify([]),
            };
        }
        const usersOj = await Users.findOne({where: {id: event.user.id, is_deleted: {[Op.not]: true}}, raw: true});
        if (event.user.role == 'Tenant') {
            const TenantsObj = await Tenants.findOne({
                where: {user_id: usersOj.id, is_deleted: {[Op.not]: true}},
                logging: console.log,
                raw: true
            });
            user_id = TenantsObj.id;
        }
        let header = event.headers;
        const query = event.pathParameters || event.queryStringParameters || {};
        if (header.offset) query.offset = parseInt(header.offset, 10);
        if (header.limit) query.limit = parseInt(header.limit, 10);
        if (query.where) query.where = JSON.parse(query.where);
        if (!query.where) {
            query.where = {};
        }
        query.where.is_deleted = {[Op.not]: true};
        if (event.user.role == 'Owner') {
            query.where.user_id = user_id;
        }
        if (event.user.role == 'Tenant') {
            query.where.tenant_id = user_id;
            query.where.property_id = login_user_info.property_id;
            query.where.unit_id = login_user_info.unit_id;
        }
        query.order = [
            ['createdAt', 'DESC'],
        ];
        query.logging = console.log;
        query.raw = true;
        const billsObj = await Bills.findAll(query);
        for (let i = 0; i < billsObj.length; i++) {
            const propertiesObj = await Properties.findOne({
                where: {
                    id: billsObj[i].property_id,
                    is_deleted: {[Op.not]: true}
                }, raw: true
            });
            if (!propertiesObj) {
                billsObj.splice(i, 1);
                i--;
                continue;
            }
            const unitsObj = await Units.findOne({
                where: {id: billsObj[i].unit_id, is_deleted: {[Op.not]: true}},
                raw: true
            });
            if (!unitsObj) {
                billsObj.splice(i, 1);
                i--;
                continue;
            }
            const tenant_table_Obj = await Tenants.findOne({
                where: {
                    id: billsObj[i].tenant_id,
                    is_deleted: {[Op.not]: true}
                }, raw: true
            });
            if (!tenant_table_Obj) {
                billsObj.splice(i, 1);
                i--;
                continue;
            }
            const tenant_user_obj = await Users.findOne({
                where: {
                    id: tenant_table_Obj.user_id,
                    role: 'Tenant',
                    is_deleted: {[Op.not]: true}
                }, raw: true
            });
            if (!tenant_user_obj) {
                billsObj.splice(i, 1);
                i--;
                continue;
            }
            billsObj[i].tenant_name = tenant_user_obj.name;
            billsObj[i].property_name = propertiesObj.property_name;
            billsObj[i].unit_name = unitsObj.unit_name;
        }

        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify(billsObj),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not fetch the  bill\'s Deatails.'}),
        };
    }
};
const update = async (event) => {
    try {
        const input = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        const pathParams = event.pathParameters || event.queryStringParameters;
        const login_user_info = event.user;
        if(login_user_info && login_user_info.role == 'Tenant' && !login_user_info.property_id && !login_user_info.unit_id) 
        {
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'text/plain',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': true
                },
                body: JSON.stringify([]),
            };
        }
        validateUpdate(pathParams);
        const {Bills, Users, Tenants, Properties, Units, Op} = await connectToDatabase();
        const billsObj = await Bills.findOne({where: {id: pathParams.id, is_deleted: {[Op.not]: true}}});
        if (!billsObj) throw new HTTPError(404, `Cannot find Bills Deatails with id ${pathParams.id}`);
        input.updatedBy = event.user.id;
        const billstb = Object.assign(billsObj, input);
        const updateBills = await billstb.save();
        const plainText = updateBills.get({plain: true});
        const propertiesObj = await Properties.findOne({
            where: {
                id: plainText.property_id,
                is_deleted: {[Op.not]: true}
            }, raw: true
        });
        plainText.property_name = propertiesObj.property_name;
        const unitsObj = await Units.findOne({where: {id: plainText.unit_id, is_deleted: {[Op.not]: true}}, raw: true});
        plainText.unit_name = unitsObj.unit_name;
        const tenant_table_Obj = await Tenants.findOne({
            where: {id: plainText.tenant_id, is_deleted: {[Op.not]: true}},
            raw: true
        });
        const tenant_user_obj = await Users.findOne({
            where: {
                id: tenant_table_Obj.user_id,
                role: 'Tenant',
                is_deleted: {[Op.not]: true}
            }, raw: true
        });
        plainText.tenant_name = tenant_user_obj.name;
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify(updateBills),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not Update the Bills.'}),
        };
    }
};
const destroy = async (event) => {
    try {
        const {Bills, Op} = await connectToDatabase();
        const pathParams = event.pathParameters || event.queryStringParameters;
        const login_user_info = event.user;
        if(login_user_info && login_user_info.role == 'Tenant' && !login_user_info.property_id && !login_user_info.unit_id) 
        {
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'text/plain',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': true
                },
                body: JSON.stringify([]),
            };
        }
        validateDestroy(pathParams);
        const billsObj = await Bills.findOne({where: {id: pathParams.id}});
        if (!billsObj) throw new HTTPError(404, `Bills with id: ${pathParams.id} was not found`);
        billsObj.is_deleted = true;
        billsObj.updatedBy = event.user.id;
        await billsObj.save();
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({
                status: 'ok',
                message: 'Bills Data removed Successfully',
            }),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not Delete the Bills.'}),
        };
    }
}
const getPrivateUploadURL = async (input) => {
    let fileExtention = '';
    let newfilename = '';
    if (input.file_name) {
        const filterarr = input.file_name.split('.');
        fileExtention = `.` + filterarr.pop();
        newfilename = filterarr.join("_");
        const randomCode = generateRandomString(8);
        newfilename = newfilename + '_' + randomCode + fileExtention;
    }

    const s3Params = {
        Bucket: process.env.S3_BUCKET_FOR_PRIVATE_FILES,
        Key: `${newfilename}`,
        ContentType: input.content_type,
        ACL: 'private',
    };

    return new Promise((resolve, reject) => {
        const uploadURL = s3.getSignedUrl('putObject', s3Params);
        resolve({
            uploadURL,
            s3_file_key: s3Params.Key,
            public_url: `https://${s3Params.Bucket}.s3.amazonaws.com/${s3Params.Key}`,
        });
    });
};
const uploadPrivateFile = async (event) => {
    try {
        const input = event.body;
        const uploadURLObject = await getPrivateUploadURL(input);
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({
                uploadURL: uploadURLObject.uploadURL,
                s3_file_key: uploadURLObject.s3_file_key,
            }),
        };
    } catch (err) {
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not upload the Private files.'}),
        };
    }
};
const getSecuredPublicUrlForPrivateFile = async (event) => {
    try {
        const input = event.body;
        AWS.config.update({region: process.env.S3_BUCKET_FOR_PRIVATE_FILES_REGION});
        const publicUrl = await s3.getSignedUrlPromise('getObject', {
            Bucket: process.env.S3_BUCKET_FOR_PRIVATE_FILES,
            Expires: 60 * 60 * 1,
            Key: input.s3_file_key,
        });
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({
                publicUrl,
            }),
        };
    } catch (err) {
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not upload the Private files.'}),
        };
    }
};
module.exports.create = middy(create).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.getOne = middy(getOne).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.getAll = getAll;
module.exports.uploadPrivateFile = uploadPrivateFile;
module.exports.getSecuredPublicUrlForPrivateFile = getSecuredPublicUrlForPrivateFile;
module.exports.update = middy(update).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.destroy = middy(destroy).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());