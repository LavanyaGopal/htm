const uuid = require('uuid');
const middy = require('@middy/core');
const doNotWaitForEmptyEventLoop = require('@middy/do-not-wait-for-empty-event-loop');
const connectToDatabase = require('../../db');
const {HTTPError} = require('../../utils/httpResp');
const authMiddleware = require('../../authMiddleware');


const getOne = async (event) => {
    try {
        const {Notification, Op} = await connectToDatabase();
        let user_id = event.user.id;
        let role = event.user.role;
        console.log(event);
        const pathParams = event.pathParameters || event.queryStringParameters || event.params;
        console.log(pathParams);
        const notificationObj = await Notification.findOne({
            where:
                {
                    user_id: user_id, user_role: role, id: pathParams.id
                }, logging: console.log,
            raw: true
        });

        if (!notificationObj) throw new HTTPError(404, `Notification with id: ${pathParams.id} was not found`);
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify(notificationObj),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not fetch the Notification Details.'}),
        };
    }
};
const getAll = async (event) => {
    try {
        const {Notification, Op} = await connectToDatabase();

        let user_id = event.user.id;
        let role = event.user.role;
        const notificationObj = await Notification.findAll({
            where:
                {
                    user_id: user_id, user_role: role, is_notification_is_readed: {[Op.not]: true}
                }, logging: console.log,
            raw: true
        });

        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify(notificationObj),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not fetch the  Notification\'s Deatails.'}),
        };
    }
};
const getNotificationCount = async (event) => {
    try {
        const {Notification, Op} = await connectToDatabase();

        let user_id = event.user.id;
        let role = event.user.role;
        const notificationObj = await Notification.count({
            where:
                {
                    user_id: user_id, user_role: role, is_notification_is_readed: {[Op.not]: true}
                }, logging: console.log,
            raw: true
        });

        const count = {notification_count: notificationObj}
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify(count),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not fetch the  Notification\'s count.'}),
        };
    }
}
const updateNotificationStatus = async (event) => {
    try {
        const {Notification, Op} = await connectToDatabase();

        let user_id = event.user.id;
        let role = event.user.role;
        // const pathParams = event.pathParameters || event.queryStringParameters || event.params;
        await Notification.update({is_notification_is_readed: true}, {
            where: {
                user_id: user_id,
                user_role: role,
                is_notification_is_readed: {[Op.not]: true}
            }
        });
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({
                status: 'Ok', message: 'success'
            }),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not update the  Notification\'s Deatails.'}),
        };
    }
}
module.exports.getAll = getAll;
module.exports.getOne = getOne;
module.exports.getNotificationCount = getNotificationCount;
module.exports.updateNotificationStatus = updateNotificationStatus;