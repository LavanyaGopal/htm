module.exports = (sequelize, type) => sequelize.define('Notification', {
    id: {
        type: type.STRING,
        primaryKey: true,
    },

    user_id: type.STRING,
    user_role: type.STRING,

    device_token: type.TEXT,
    notification_type: type.STRING, // bill/issue/issue_resolved
    notification_type_id: type.STRING, // bill/issue - ids.
    property_name: type.TEXT,
    unit_name: type.TEXT,
    title: type.TEXT,
    message: type.TEXT,
    is_notification_is_readed: type.BOOLEAN, // Before GetAll api call 0 after GetAll api call 1;
    createdBy: type.STRING,
    updatedBy: type.STRING,
});