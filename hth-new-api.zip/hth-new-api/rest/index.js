const serverless = require('serverless-http');
const bodyParser = require('body-parser');
const express = require('express');
const cors = require('cors');

const healthCheckApi = require('../handler');
const authMiddleware = require('../authExpress');
const UsersApi = require('./users/controller');
const PropertiesApi = require('./properties/controller');
const MaintenanceApi = require('./maintenance/controller');
const UnitApi = require('./units/controller');
const IssuesApi = require('./issues/controller');
const BillsApi = require('./bills/controller');
const TenantsApi = require('./tenants/controller');
const UtilApi = require('./util/util');
const NotificationApi = require('./notifications/controller');
const SettingApi = require('./settings/controller');

const app = express();
app.use(bodyParser.json({strict: false}));

app.use(cors());
app.options('*', cors());

app.get('/rest/', async (req, res) => {
    try {
        const responseData = await healthCheckApi.healthCheck(req);
        return res
            .status(responseData.statusCode)
            .json(JSON.parse(responseData.body));
    } catch (err) {
        return res
            .status(err.statusCode || 500)
            .json({error: err.message});
    }
});
/* Users */
app.get('/rest/users', authMiddleware, async (req, res) => { /* Checked */
    try {
        const responseData = await UsersApi.getAll(req);
        return res
            .status(responseData.statusCode)
            .json(JSON.parse(responseData.body));
    } catch (err) {
        return res
            .status(err.statusCode || 500)
            .json({error: err.message});
    }
});
/* Update Profile */
// app.put('/rest/users/update-profile', authMiddleware, async (req, res) => {
//     try {
//         const responseData = await UsersApi.updateProfile(req);
//         return res
//             .status(responseData.statusCode)
//             .json(JSON.parse(responseData.body));
//     } catch (err) {
//         return res
//             .status(err.statusCode || 500)
//             .json({ error: err.message });
//     }
// });

/* Properties */ 
app.get('/rest/properties', authMiddleware, async (req, res) => { /* Checked */
    try {
        const responseData = await PropertiesApi.getAll(req);
        return res
            .status(responseData.statusCode)
            .json(JSON.parse(responseData.body));
    } catch (err) {
        return res
            .status(err.statusCode || 500)
            .json({error: err.message});
    }
});
/* Maintenance */
app.get('/rest/maintenance', authMiddleware, async (req, res) => { /* Checked */
    try {
        const responseData = await MaintenanceApi.getAll(req);
        return res
            .status(responseData.statusCode)
            .json(JSON.parse(responseData.body));
    } catch (err) {
        return res
            .status(err.statusCode || 500)
            .json({error: err.message});
    }
});
/* Unit */
app.get('/rest/units', authMiddleware, async (req, res) => { /* Checked */
    try {
        const responseData = await UnitApi.getAll(req);
        return res
            .status(responseData.statusCode)
            .json(JSON.parse(responseData.body));
    } catch (err) {
        return res
            .status(err.statusCode || 500)
            .json({error: err.message});
    }
});
/* Issues */
app.get('/rest/issues', authMiddleware, async (req, res) => { 
    try {
        const responseData = await IssuesApi.getAll(req);
        return res
            .status(responseData.statusCode)
            .json(JSON.parse(responseData.body));
    } catch (err) {
        return res
            .status(err.statusCode || 500)
            .json({error: err.message});
    }
});
/* Bills */
app.get('/rest/bills', authMiddleware, async (req, res) => {
    try {
        const responseData = await BillsApi.getAll(req);
        return res
            .status(responseData.statusCode)
            .json(JSON.parse(responseData.body));
    } catch (err) {
        return res
            .status(err.statusCode || 500)
            .json({error: err.message});
    }
});
/* Tenants */
app.get('/rest/tenants', authMiddleware, async (req, res) => { /* Checked */
    try {
        const responseData = await TenantsApi.getAll(req);
        return res
            .status(responseData.statusCode)
            .json(JSON.parse(responseData.body));
    } catch (err) {
        return res
            .status(err.statusCode || 500)
            .json({error: err.message});
    }
});
// updating the tenant phoen number adne email.
app.patch('/rest/tenants/:id', authMiddleware, async (req, res) => {
    try {
        const responseData = await TenantsApi.update(req);
        return res
            .status(responseData.statusCode)
            .json(JSON.parse(responseData.body));
    } catch (err) {
        return res
            .status(err.statusCode || 500)
            .json({ error: err.message });
    }
});

/* Dropdown api's */
app.get('/rest/dropdown/properties', authMiddleware, async (req, res) => {
    try {
        const responseData = await PropertiesApi.dropdown(req);
        return res
            .status(responseData.statusCode)
            .json(JSON.parse(responseData.body));
    } catch (err) {
        return res
            .status(err.statusCode || 500)
            .json({error: err.message});
    }
});
app.get('/rest/dropdown/units', authMiddleware, async (req, res) => {
    try {
        const responseData = await UnitApi.dropdown(req);
        return res
            .status(responseData.statusCode)
            .json(JSON.parse(responseData.body));
    } catch (err) {
        return res
            .status(err.statusCode || 500)
            .json({error: err.message});
    }
});
app.get('/rest/dropdown/tenants', authMiddleware, async (req, res) => {
    try {
        const responseData = await TenantsApi.dropdown(req);
        return res
            .status(responseData.statusCode)
            .json(JSON.parse(responseData.body));
    } catch (err) {
        return res
            .status(err.statusCode || 500)
            .json({error: err.message});
    }
});
app.get('/rest/dropdown/maintenance', authMiddleware, async (req, res) => {
    try {
        const responseData = await MaintenanceApi.dropdown(req);
        return res
            .status(responseData.statusCode)
            .json(JSON.parse(responseData.body));
    } catch (err) {
        return res
            .status(err.statusCode || 500)
            .json({error: err.message});
    }
});
app.get('/rest/test-sms', async (req, res) => {
    try {
        const responseData = await UtilApi.testSMS(req);
        return res
            .status(responseData.statusCode)
            .json(JSON.parse(responseData.body));
    } catch (err) {
        return res
            .status(err.statusCode || 500)
            .json({error: err.message});
    }
});
app.post('/rest/billing/upload-private-file', authMiddleware, async (req, res) => {
    try {
        const responseData = await BillsApi.uploadPrivateFile(req);
        return res
            .status(responseData.statusCode)
            .json(JSON.parse(responseData.body));
    } catch (err) {
        return res
            .status(err.statusCode || 500)
            .json({error: err.message});
    }
});
app.post('/rest/billing/get-secure-public-url-of-private-file', authMiddleware, async (req, res) => {
    try {
        const responseData = await BillsApi.getSecuredPublicUrlForPrivateFile(req);
        return res
            .status(responseData.statusCode)
            .json(JSON.parse(responseData.body));
    } catch (err) {
        return res
            .status(err.statusCode || 500)
            .json({error: err.message});
    }
});
app.get('/rest/notification', authMiddleware, async (req, res) => {
    try {
        const responseData = await NotificationApi.getAll(req);
        return res
            .status(responseData.statusCode)
            .json(JSON.parse(responseData.body));
    } catch (err) {
        return res
            .status(err.statusCode || 500)
            .json({error: err.message});
    }
});
app.get('/rest/notification/:id', authMiddleware, async (req, res) => {
    try {
        const responseData = await NotificationApi.getOne(req);
        return res
            .status(responseData.statusCode)
            .json(JSON.parse(responseData.body));
    } catch (err) {
        return res
            .status(err.statusCode || 500)
            .json({error: err.message});
    }
});
app.post('/rest/update-notification-status', authMiddleware, async (req, res) => {
    try {
        const responseData = await NotificationApi.updateNotificationStatus(req);
        return res
            .status(responseData.statusCode)
            .json(JSON.parse(responseData.body));
    } catch (err) {
        return res
            .status(err.statusCode || 500)
            .json({error: err.message});
    }
});
app.get('/rest/notification-count', authMiddleware, async (req, res) => {
    try {
        const responseData = await NotificationApi.getNotificationCount(req);
        return res
            .status(responseData.statusCode)
            .json(JSON.parse(responseData.body));
    } catch (err) {
        return res
            .status(err.statusCode || 500)
            .json({error: err.message});
    }
});
/* Settings */
app.post('/rest/settings/upload-file', authMiddleware, async (req, res) => {
    try {
        const responseData = await SettingApi.userUploadFile(req);
        return res
            .status(responseData.statusCode)
            .json(JSON.parse(responseData.body));
    } catch (err) {
        return res
            .status(err.statusCode || 500)
            .json({error: err.message});
    }
});
module.exports.handler = serverless(app);