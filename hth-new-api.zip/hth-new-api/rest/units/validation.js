const Validator = require('validatorjs');
const commonPassword = require('common-password-checker');
const {HTTPError} = require('../../utils/httpResp');

exports.validateCreate = (data) => {
    const rules = {
        user_id: 'required',
        property_id: 'required',
        unit_number: 'required',
        unit_type: 'required',
        rent: 'required',
        unit_code: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
}

exports.validateDropdown = (data) => {
    const rules = {
        user_id: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
}
exports.validateGetOne = function (data) {
    const rules = {
        id: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
};
exports.validateUpdate = function (data) {
    const rules = {
        id: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
};
exports.validateDestroy = function (data) {
    const rules = {
        id: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
};        
