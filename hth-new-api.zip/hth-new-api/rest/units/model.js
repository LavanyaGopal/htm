module.exports = (sequelize, type) => sequelize.define('Unit', {
    id: {
        type: type.STRING,
        primaryKey: true,
    },
    user_id: {
        type: type.STRING,
        allowNull: false,
    },
    property_id: {
        type: type.STRING,
        allowNull: false,
    },
    unit_code: {
        type: type.STRING,
        allowNull: false,
        //unique: true
    },
    unit_number: type.STRING,   //Auto Generate
    unit_name: type.STRING,
    unit_type: type.STRING,
    unit_order: type.STRING,
    unit_status: type.STRING,  //Available, NotAvailable - changing it to Vacant, Occupied
    rent: type.STRING,
    photos: type.TEXT,
    electricity_bill_no: type.TEXT,
    water_bill_no: type.TEXT,
    gas_bill_no: type.TEXT,
    is_deleted: type.BOOLEAN,
    createdBy: type.STRING,
    updatedBy: type.STRING,
});