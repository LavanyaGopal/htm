const uuid = require('uuid');
const middy = require('@middy/core');
const doNotWaitForEmptyEventLoop = require('@middy/do-not-wait-for-empty-event-loop');
const connectToDatabase = require('../../db');
const {HTTPError} = require('../../utils/httpResp');
const authMiddleware = require('../../authMiddleware');
const {generateRandomString} = require('../../utils/randomStringGenerator');
const {validateDropdown, validateCreate, validateGetOne, validateUpdate, validateDestroy} = require('./validation');
const create = async (event) => {
    try {
        let id;
        const input = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        let unitCode = generateRandomString(8);
        const {Units, Op, Properties, Users} = await connectToDatabase();
        let existingUnitCount = await Units.count({where: {property_id: input.property_id}});
        existingUnitCount += 1;
        const propertiesObj = await Properties.findOne({
            where: {id: input.property_id, is_deleted: {[Op.not]: true}}, raw: true
        });
        if (!propertiesObj) throw new HTTPError(404, `Properties for this ${input.property_id} was not found`);
        const propertyCount = propertiesObj.total_units;
        let plainText;
        if (existingUnitCount <= propertyCount) {
            const dataObject = Object.assign(input, {
                id: id || uuid.v4(),
                unit_status: input.unit_status,  // if the unit is "Not Available" will the dupliacte unit be added?
                user_id: event.user.id,
                unit_order: existingUnitCount,
                unit_code: unitCode,
                createdBy: event.user.id
            });
            validateCreate(dataObject);
            const unitsObj = await Units.create(dataObject);
            plainText = unitsObj.get({plain: true});
        } else {
            throw new HTTPError(400, `Unit count existing for this property`);
        }

        const ownerObj = await Users.findOne({where: {id: plainText.user_id, is_deleted: {[Op.not]: true}}});
        if (!ownerObj) throw new HTTPError(404, `Owner for this ${plainText.user_id} was not found`);

        plainText.owner_name = ownerObj.name;
        plainText.owner_email = ownerObj.email;
        plainText.owner_phone = ownerObj.phone;
        plainText.owner_country_code = ownerObj.country_code;
        plainText.owner_role = ownerObj.role;
        plainText.property_name = propertiesObj.property_name;
        const createdUserObj = await Users.findOne({where: {id: plainText.createdBy, is_deleted: {[Op.not]: true}}});
        if (!createdUserObj) throw new HTTPError(404, `Units Created user for this ${plainText.createdBy} was not found`);
        plainText.created_by = createdUserObj.name;


        return {
            statusCode: 200, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify(plainText),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Could not create the unit deatails.'}),
        };
    }
};
const getAll = async (event) => {
    try {
        let header = event.headers;
        const {Units, Op, Properties, Users} = await connectToDatabase();
        const query = event.queryStringParameters || {};
        if (header.offset) query.offset = parseInt(header.offset, 10);
        if (header.limit) query.limit = parseInt(header.limit, 10);
        if (query.where) query.where = JSON.parse(query.where);
        if (!query.where) {
            query.where = {};
        }
        query.where.user_id = event.user.id;
        query.where.is_deleted = {[Op.not]: true};
        query.order = [['createdAt', 'DESC']];
        query.raw = true;
        const unitsObj = await Units.findAll(query);
        for (let i = 0; i < unitsObj.length; i++) {
            const ownerObj = await Users.findOne({where: {id: unitsObj[i].user_id, is_deleted: {[Op.not]: true}}});
            if (!ownerObj) {
                unitsObj.splice(i, 1);
                i--;
                continue;
            }
            unitsObj[i].owner_name = ownerObj.name;
            unitsObj[i].owner_email = ownerObj.email;
            unitsObj[i].owner_phone = ownerObj.phone;
            unitsObj[i].owner_country_code = ownerObj.country_code;
            unitsObj[i].owner_role = ownerObj.role;
            const propertiesObj = await Properties.findOne({
                where: {
                    id: unitsObj[i].property_id, user_id: unitsObj[i].user_id, is_deleted: {[Op.not]: true}
                }
            });
            if (!propertiesObj) {
                unitsObj.splice(i, 1);
                i--;
                continue;
            }
            unitsObj[i].property_name = propertiesObj.property_name;
            const createdUserObj = await Users.findOne({
                where: {
                    id: unitsObj[i].createdBy, is_deleted: {[Op.not]: true}
                }
            });
            if (!createdUserObj) {
                unitsObj.splice(i, 1);
                i--;
                continue;
            }
            unitsObj[i].created_by = createdUserObj.name;
        }
        return {
            statusCode: 200, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify(unitsObj),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Could not get units Deatails.'}),
        };
    }
};
const getOne = async (event) => {
    try {
        const input = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        const pathParams = event.pathParameters;
        validateGetOne(pathParams);
        const {Units, Op, Properties, Users} = await connectToDatabase();
        const unitsObj = await Units.findOne({
            where: {id: pathParams.id, is_deleted: {[Op.not]: true}}, logging: console.log
        });
        if (!unitsObj) throw new HTTPError(404, `Units for this ${pathParams.id} was not found`);
        const propertiesObj = await Properties.findOne({
            where: {
                id: unitsObj.property_id, user_id: unitsObj.user_id, is_deleted: {[Op.not]: true}
            }
        });
        if (!propertiesObj) throw new HTTPError(404, `Properties for this ${unitsObj.property_id} was not found`)
        unitsObj.property_name = propertiesObj.property_name;
        const ownerObj = await Users.findOne({where: {id: unitsObj.user_id, is_deleted: {[Op.not]: true}}});
        if (!ownerObj) throw new HTTPError(404, `Units details for this ${unitsObj.user_id} was not found`)
        unitsObj.owner_name = ownerObj.name;
        unitsObj.owner_email = ownerObj.email;
        unitsObj.owner_phone = ownerObj.phone;
        unitsObj.owner_country_code = ownerObj.country_code;
        unitsObj.owner_role = ownerObj.role;
        const createdUserObj = await Users.findOne({where: {id: unitsObj.createdBy, is_deleted: {[Op.not]: true}}});
        if (!createdUserObj) throw new HTTPError(404, `Created User details for this ${unitsObj.createdBy} was not found`)
        unitsObj.created_by = createdUserObj.name;

        return {
            statusCode: 200, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify(unitsObj),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Could not get untis Deatails.'}),
        };
    }
};
const update = async (event) => {
    try {
        const input = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        const pathParams = event.pathParameters;
        validateUpdate(pathParams);
        const {Units, Op, Properties, Users} = await connectToDatabase();
        const unitsObj = await Units.findOne({where: {id: pathParams.id, is_deleted: {[Op.not]: true}}});
        if (!unitsObj) throw new HTTPError(404, `Units details for this ${pathParams.id} was not found`);
        input.updatedBy = event.user.id;
        const unitstb = Object.assign(unitsObj, input);

        const unitsUpdate = await unitstb.save();
        const plainText = unitsUpdate.get({plain: true});

        const propertiesObj = await Properties.findOne({
            where: {
                id: plainText.property_id, user_id: plainText.user_id, is_deleted: {[Op.not]: true}
            }
        });
        if (!propertiesObj) throw new HTTPError(404, `Property details for this ${plainText.property_id} was not found`)
        plainText.property_name = propertiesObj.property_name;
        const ownerObj = await Users.findOne({where: {id: plainText.user_id, is_deleted: {[Op.not]: true}}});
        if (!ownerObj) throw new HTTPError(404, `Owner details for this ${plainText.user_id} was not found`)
        plainText.owner_name = ownerObj.name;
        plainText.owner_email = ownerObj.email;
        plainText.owner_phone = ownerObj.phone;
        plainText.owner_country_code = ownerObj.country_code;
        plainText.owner_role = ownerObj.role;
        const createdUserObj = await Users.findOne({where: {id: plainText.createdBy, is_deleted: {[Op.not]: true}}});
        if (!createdUserObj) throw new HTTPError(404, `Created user details for this ${plainText.createdBy} was not found`)
        plainText.created_by = createdUserObj.name;

        return {
            statusCode: 200, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify(plainText),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Could not update the units Deatails.'}),
        };
    }
};
const destroy = async (event) => {
    try {
        const pathParams = event.pathParameters || event.queryStringParameters;
        validateDestroy(pathParams);
        const {Units, Op} = await connectToDatabase();
        const unitsObj = await Units.findOne({where: {id: pathParams.id, is_deleted: {[Op.not]: true}}});
        if (!unitsObj) throw new HTTPError(404, `Units for this ${pathParams.id} was not found`);
        unitsObj.updatedBy = event.user.id;
        unitsObj.is_deleted = true;
        await unitsObj.save();
        return {
            statusCode: 200, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({
                status: 'ok', message: 'Successfully Units Data removed',
            }),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Could not Delete Units Deatails.'}),
        };
    }
};
const dropdown = async (event) => {
    try {
        let header = event.headers;
        const input = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        const {Units, Op, Properties, Users} = await connectToDatabase();
        const query = event.queryStringParameters || {};
        if (header.offset) query.offset = parseInt(header.offset, 10);
        if (header.limit) query.limit = parseInt(header.limit, 10);
        if (query.where) query.where = JSON.parse(query.where);
        if (!query.where) {
            query.where = {};
        }
        query.where.user_id = event.user.id;
        query.where.is_deleted = {[Op.not]: true};
        query.order = [['createdAt', 'DESC']];
        query.raw = true;
        const unitsObj = await Units.findAll(query);
        for (let i = 0; i < unitsObj.length; i++) {
            const ownerObj = await Users.findOne({where: {id: unitsObj[i].user_id, is_deleted: {[Op.not]: true}}});
            if (!ownerObj) {
                unitsObj.splice(i, 1);
                i--;
                continue;
            }
            unitsObj[i].owner_name = ownerObj.name;
            unitsObj[i].owner_email = ownerObj.email;
            unitsObj[i].owner_phone = ownerObj.phone;
            unitsObj[i].owner_country_code = ownerObj.country_code;
            unitsObj[i].owner_role = ownerObj.role;
            const propertiesObj = await Properties.findOne({
                where: {
                    id: unitsObj[i].property_id, user_id: unitsObj[i].user_id, is_deleted: {[Op.not]: true}
                }
            });
            if (!propertiesObj) {
                unitsObj.splice(i, 1);
                i--;
                continue;
            }
            unitsObj[i].property_name = propertiesObj.property_name;
            const createdUserObj = await Users.findOne({
                where: {
                    id: unitsObj[i].createdBy, is_deleted: {[Op.not]: true}
                }
            });
            if (!createdUserObj) {
                unitsObj.splice(i, 1);
                i--;
                continue;
            }
            unitsObj[i].created_by = createdUserObj.name;
        }
        return {
            statusCode: 200, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify(unitsObj),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Could not Fetch Units Deatails.'}),
        };
    }
}
module.exports.create = middy(create).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.getAll = getAll;
module.exports.getOne = middy(getOne).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.update = middy(update).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.destroy = middy(destroy).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.dropdown = dropdown;
