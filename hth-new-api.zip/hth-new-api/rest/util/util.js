const {generateRandomString} = require('../../utils/randomStringGenerator');
const {sendSMS} = require('../../utils/smsModule');
const AWS = require('aws-sdk');
const testSMS = async (event) => {
    try {
        const phoneCountryCode = process.env.PHONE_COUNTRY_CODE || '+91';
        let phone = '9360722593';
        let smstext_body = "Your OTP verification code is ";
        let response = await sendSMS(`${phoneCountryCode}${phone}`, 'HomeAtHome-OTP', smstext_body);
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify(response),
        };

    } catch (err) {
        console.log(err);
    }
}
module.exports.testSMS = testSMS;    