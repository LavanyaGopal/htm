//##up
// const express = require('express');
// const router = express.Router();
// const usersController = require('./controller');
// const authenticateToken = require('../../authenticateToken');  // Adjust if needed

// // PUT /api/users/update-profile
// router.put('/update-profile', authenticateToken, usersController.updateProfile);

// module.exports = router;
