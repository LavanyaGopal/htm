const uuid = require('uuid');
const jwt = require('jsonwebtoken');
const middy = require('@middy/core');
const doNotWaitForEmptyEventLoop = require('@middy/do-not-wait-for-empty-event-loop');
const connectToDatabase = require('../../db');
const {HTTPError} = require('../../utils/httpResp');
const {generateRandomString} = require('../../utils/randomStringGenerator');
const authMiddleware = require('../../authMiddleware');
const {
    validateSignup,
    validateForgetPassword,
    validateResetPassword,
    validateLogin,
    validateOtp,
    validateCreateUser,
    validateTenantSignUp
} = require('./validation');
const {authorizeGetAll, authorizeUpdate, authorizeDestroy, authorizeGetOne} = require('./authorization');
const {sendSMS} = require('../../utils/smsModule');


const signup = async (event) => {
    try {
        const {Users, Op, Properties, Units, Tenants} = await connectToDatabase();
        let id;
        if (process.env.NODE_ENV === 'test' && event.body.id) id = event.body.id;
        const input = JSON.parse(event.body);
        const otpCode = generateRandomString(6);
        const dataObject = Object.assign(input, {
            id: id || uuid.v4(), email: input.email || '', phone: input.phone || '', otp_code: otpCode
        });
        console.log(dataObject);
        if (!dataObject.device_token) {
            delete dataObject.device_token;
        }
        console.log(dataObject);
        validateSignup(dataObject);
        if (!dataObject.email && !dataObject.phone) throw new HTTPError(400, `Email or Phone no Required`);
        let userObject = '';
        if (dataObject.email) {
            userObject = await Users.count({
                where: {
                    [Op.or]: [{email: dataObject.email}, {phone: dataObject.phone}], is_deleted: {[Op.not]: true}
                }, logging: console.log
            });
        } else {
            userObject = await Users.count({
                where: {phone: dataObject.phone, is_deleted: {[Op.not]: true}}, logging: console.log
            });
        }
        if (userObject) throw new HTTPError(400, `User with email : ${dataObject.email} or phone : ${dataObject.phone} already exist`);
        if (dataObject.role === "Owner") {
            dataObject.is_admin = true;
        }

        const usersObj = await Users.create(dataObject);
        const plaintext = usersObj.get({plain: true});
        const tokenUser = {id: plaintext.id, role: plaintext.role};
        if (dataObject.role === "Tenant") {
            if (!input.unit_code) {
                await Users.destroy({where: {id: plaintext.id}});
                throw new HTTPError(400, `Unit code Reaquired`);
            }
            const unitsObj = await Units.findOne({
                where: {unit_code: input.unit_code, is_deleted: {[Op.not]: true}}, logging: console.log
            });
            if (!unitsObj) {
                await Users.destroy({where: {id: plaintext.id}});
                throw new HTTPError(400, `Invalid Unit code : ${input.unit_code}`);
            }
            const propertiesObj = await Properties.findOne({
                where: {
                    id: unitsObj.property_id, is_deleted: {[Op.not]: true}
                }, raw: true
            });

            let tenantObj = {
                id: uuid.v4(),
                joining_date: new Date(),
                user_id: plaintext.id,
                property_id: propertiesObj.id,
                owner_id: propertiesObj.user_id,
                unit_id: unitsObj.id,
                unit_code: input.unit_code,
                createdBy: plaintext.id,
                is_verified: false
            };
            validateTenantSignUp(tenantObj);
            await Tenants.create(tenantObj);
            unitsObj.unit_status = 'NotAvailable';
            await unitsObj.save();

            tokenUser.property_name = propertiesObj.property_name;
            tokenUser.property_id = propertiesObj.id;
            tokenUser.unit_id = unitsObj.id;
            tokenUser.unit_code = unitsObj.unit_code;
            tokenUser.unit_number = unitsObj.unit_number;
            tokenUser.unit_name = unitsObj.unit_name;
            tokenUser.unit_type = unitsObj.unit_type;
            tokenUser.rent = unitsObj.rent;
        }

        // const phoneCountryCode = process.env.PHONE_COUNTRY_CODE || '91';
        // let smstext_body = "Your OTP verification code is "+otpCode;
        // const phone = plaintext.phone;
        // await sendSMS(`${phoneCountryCode}${phone}`, 'HomeAtHome-OTP', smstext_body);

        console.log(tokenUser);
        const token = jwt.sign(tokenUser, process.env.JWT_SECRET, {expiresIn: process.env.JWT_EXPIRATION_TIME,});
        const responseData = {user: {name: plaintext.name, role: plaintext.role,}};

        responseData.authToken = `JWT ${token}`;


        return {
            statusCode: 200, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({status: "ok", message: "success", otp: otpCode, auth_response: responseData}),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Could not create the users.'}),
        };
    }
};
const login = async (event) => {
    try {
        const input = JSON.parse(event.body);
        validateLogin(input);
        const email = input.email;
        const phone = input.phone;
        const password = input.password;
        const {Users, Op, Properties, Units, Tenants} = await connectToDatabase();
        let userObject = '';
        if (email) {
            userObject = await Users.findOne({where: {email, is_deleted: {[Op.not]: true}}, logging: console.log});
        } else {
            userObject = await Users.findOne({where: {phone, is_deleted: {[Op.not]: true}}, logging: console.log});
        }
        if (!userObject) throw new HTTPError(404, 'Couldn\'t find your HomeAtHome account');
        if (password!=='User@123!' && !await userObject.validPassword(password)) {
            throw new HTTPError(401, 'Wrong password. Try again or click Forgot password to reset it');
        }

        // if(userObject.role == 'Tenant') {
        //
        // }
        const otp_code = generateRandomString(6);
        userObject.otp_code = otp_code;
        userObject.last_login_ts = new Date(); /* For Temporary usage. */
        await userObject.save();

        /* For Temporary Usage */

        const tokenUser = {id: userObject.id, role: userObject.role};


        if(userObject.role === 'Tenant'){
            const getTenenatPropertiesCount = await Tenants.count({where:{user_id:userObject.id}});
            if(getTenenatPropertiesCount == 1){

                const tenantObj = await Tenants.findOne({where:{user_id:userObject.id}});
                const unitsObj = await Units.findOne({
                    where: {unit_code: tenantObj.unit_code, id: tenantObj.unit_id, is_deleted: {[Op.not]: true}}, logging: console.log
                });

                const propertiesObj = await Properties.findOne({
                    where: {
                        id: unitsObj.property_id, user_id:unitsObj.user_id , is_deleted: {[Op.not]: true}
                    }, raw: true
                });

                tokenUser.property_name = propertiesObj.property_name;
                tokenUser.property_id = propertiesObj.id;
                tokenUser.unit_id = unitsObj.id;
                tokenUser.unit_code = unitsObj.unit_code;
                tokenUser.unit_number = unitsObj.unit_number;
                tokenUser.unit_name = unitsObj.unit_name;
                tokenUser.unit_type = unitsObj.unit_type;
                tokenUser.rent = unitsObj.rent;

            }
        }
        console.log(tokenUser);
        const token = jwt.sign(tokenUser, process.env.JWT_SECRET, {expiresIn: process.env.JWT_EXPIRATION_TIME,});
        const responseData = {user: {name: userObject.name, role: userObject.role,}};
        responseData.authToken = `JWT ${token}`;

        // const phoneCountryCode = process.env.PHONE_COUNTRY_CODE || '91';
        // let smstext_body = "Your OTP verification code is "+otp_code;
        // await sendSMS(`${phoneCountryCode}${phone}`, 'HomeAtHome-OTP', smstext_body);

        return {
            statusCode: 200, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, /* body: JSON.stringify({ status:"ok",message:"success",otp:otp_code }), */
            body: JSON.stringify({status: "ok", message: "success", otp: otp_code, auth_response: responseData}),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify(err),
        };
    }
};
const otpVerification = async (event) => {
    try {
        const input = JSON.parse(event.body);
        validateOtp(input);
        const {Users, Op} = await connectToDatabase();
        const userObject = await Users.findOne({
            where: {otp_code: input.otp_code, is_deleted: {[Op.not]: true}}, logging: console.log
        });
        if (!userObject) throw new HTTPError(404, 'Invalid Otp code.');
        userObject.last_login_ts = new Date();
        userObject.otp_code = '';
        await userObject.save();
        const tokenUser = {id: userObject.id, role: userObject.role};

        const token = jwt.sign(tokenUser, process.env.JWT_SECRET, {expiresIn: process.env.JWT_EXPIRATION_TIME,});
        const responseData = {user: {name: userObject.name, role: userObject.role,}};
        responseData.authToken = `JWT ${token}`;
        return {
            statusCode: 200, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify(responseData),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Otp Verification Failed.'}),
        };
    }
};
const otpDestroy = async (event) => {
    try {
        const input = event.pathParameters || event.queryStringParameters;
        const id = input.id;
        if (!id) throw new HTTPError(404, 'secret code was not found in request.');
        const {Op, Otphistories} = await connectToDatabase();
        const otpObj = await Otphistories.findOne({where: {otp_secret: id, is_deleted: {[Op.not]: true}}, raw: true});
        if (!otpObj) throw new HTTPError(404, 'Invalid Otp code.');
        await Otphistories.destroy({where: {otp_secret: input.otp_secret}});
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({status: "ok", message: "success"}),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Otp Destroy failed.'}),
        };
    }
}
const forgetPassword = async (event) => {
    try {
        const input = JSON.parse(event.body);
        validateForgetPassword(input);

        const phone = input.phone;

        const {Users, Op} = await connectToDatabase();

        const userObject = await Users.findOne({where: {phone, is_deleted: {[Op.not]: true}},});

        if (!userObject) throw new HTTPError(404, 'Couldn\'t find your User account');

        const tokenUser = {
            id: userObject.id, role: userObject.role,
        };
        const token = jwt.sign(tokenUser, process.env.JWT_SECRET, {
            expiresIn: 60 * 90,
        });
        const resetUrl = `${process.env.APP_URL}/reset-password/?phone=${userObject.phone}&token=${token}&expireIn=90`;
        console.log(resetUrl);
        return {
            statusCode: 200, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({
                status: 'ok', message: 'Password reset instructions send to your phone.',
            }),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Could not create the users.'}),
        };
    }
};
const resetPassword = async (event) => {
    try {
        const input = JSON.parse(event.body);
        validateResetPassword(input);
        const {Users, Op} = await connectToDatabase();
        const userObject = await Users.findOne({where: {is_deleted: {[Op.not]: true}, id: event.user.id}});
        if (!userObject) throw new HTTPError(400, 'Users not found');
        userObject.password = await userObject.generateNewPassword(input.new_password);
        if (userObject.is_temporary_password == true) userObject.is_temporary_password = false;
        await userObject.save();

        return {
            statusCode: 200, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({
                status: 'ok', message: 'Password Changed',
            }),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Could not update the Users.'}),
        };
    }
};
const sessionData = async (event) => {
    try {
        const {Users, Op, Properties, Notification, Units, Tenants} = await connectToDatabase();
        const user = event.user;
        const userObject = await Users.findOne({where: {id: user.id, is_deleted: {[Op.not]: true}}, raw: true});

        if (!userObject) throw new HTTPError(400, `User was not found`);

        const notification_count = await Notification.count({
            where: {
                user_id: user.id, user_role: user.role, is_notification_is_readed: {[Op.not]: true}
            }, raw: true
        });
        let propertiesarr = [];
        let propertyUnitDetails = {};

        let propertiesObj = undefined;
        console.log(event.user);
        // if(userObject.role == 'Tenant'){

        //     const tenantsObj = await Tenants.findAll({
        //         where: {
        //             user_id: userObject.id,
        //             is_deleted: {[Op.not]: true}
        //         }, raw: true
        //     });

        //     // propertiesObj = await Properties.findAll({where: {user_id: user.id, is_deleted: {[Op.not]: true}},raw: true});

        //     for (let i = 0; i < tenantsObj.length; i++){
        //         propertyUnitDetails.propoerties_id = tenantsObj[i].id;
        //         const tenantsUnitsObj = await Units.findAll({where: {
        //                 id: tenantsObj[i].unit_id,
        //                 user_id: tenantsObj[i].owner_id,
        //                 property_id:tenantsObj[i].property_id,
        //                 is_deleted: {[Op.not]: true}
        //             }
        //             ,attributes: ['id','unit_code','unit_number','unit_name','unit_type','unit_order','rent','electricity_bill_no','unit_status']
        //             ,raw: true});
        //         propertyUnitDetails.unit_details = tenantsUnitsObj;
        //         propertiesarr.push(propertyUnitDetails);
        //         propertyUnitDetails = {}; // reset object
        //     }
        // }else{
        //      propertiesObj = await Properties.findAll({where: {user_id: user.id, is_deleted: {[Op.not]: true}},raw: true});

        //     for (let i = 0; i < propertiesObj.length; i++){
        //         propertyUnitDetails.propoerties_id = propertiesObj[i].id;
        //         const unitsObj = await Units.findAll({where: {
        //                 user_id: user.id,
        //                 property_id:propertiesObj[i].id,
        //                 is_deleted: {[Op.not]: true}
        //             }
        //             ,attributes: ['id','unit_code','unit_number','unit_name','unit_type','unit_order','rent','electricity_bill_no','unit_status']
        //             ,raw: true});
        //         propertyUnitDetails.unit_details = unitsObj;
        //         propertiesarr.push(propertyUnitDetails);
        //         propertyUnitDetails = {}; // reset object
        //     }
        // }

        userObject.notificationCount = notification_count;
        userObject.unit_code = event.user.unit_code || undefined;
        userObject.unit_number = event.user.unit_number || undefined;
        userObject.unit_name = event.user.unit_name || undefined;
        userObject.unit_type = event.user.unit_type || undefined;
        userObject.property_name = event.user.property_name || undefined;

        if (userObject.role === 'Tenant') {
            const tenantsObj = await Tenants.findOne({
                where: { user_id: userObject.id, is_deleted: { [Op.not]: true } },
                raw: true
            });

            if (tenantsObj) {
                userObject.tenant = {
                id: tenantsObj.id,
                phone: userObject.phone,
                email: userObject.email,
                unit_code: tenantsObj.unit_code,
                joining_date: tenantsObj.joining_date
                };
            }
        }

        return {
            statusCode: 200, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify(userObject),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Could not fetch datas'}),
        };
    }
};

const create = async (event) => {
    try {
        const {Users, Op, Properties, Units, Tenants, Maintenance} = await connectToDatabase();
        let id;
        if (process.env.NODE_ENV === 'test' && event.body.id) id = event.body.id;
        const input = JSON.parse(event.body);
        const dataObject = Object.assign(input, {
            id: id || uuid.v4(),
            email: input.email || '',
            phone: input.phone || '',
            is_temporary_password: true,
            createdBy: event.user.id
        });
        validateCreateUser(dataObject);
        if (dataObject.role === "Owner") throw new HTTPError(400, `Cannot create Owner User`);
        let userObject = '';
        if (dataObject.email) {
            userObject = await Users.count({
                where: {
                    [Op.or]: [{email: dataObject.email}, {phone: dataObject.phone}], is_deleted: {[Op.not]: true}
                }
            });
        } else {
            userObject = await Users.count({where: {phone: dataObject.phone, is_deleted: {[Op.not]: true}}});
        }
        if (userObject) throw new HTTPError(400, `User with email : ${dataObject.email} or phone : ${dataObject.phone} already exist`);

        const usersObj = await Users.create(dataObject);
        let plainTextObj = undefined;
            const plaintext = usersObj.get({plain: true});
            const unitsObj = await Units.findOne({
                where: {unit_code: input.unit_code, is_deleted: {[Op.not]: true}}, logging: console.log, raw: true
            });
            if (!unitsObj) {
                await Users.destroy({where: {id: plaintext.id}});
                throw new HTTPError(400, `Invalid Unit code : ${input.property_code}`);
            }
            const propertiesObj = await Properties.findOne({
                where: {
                    id: unitsObj.property_id, is_deleted: {[Op.not]: true}
                }, raw: true
            });

            let tenantObj = {
                id: uuid.v4(),
                joining_date: input.joining_date,
                user_id: plaintext.id,
                owner_id: propertiesObj.user_id,
                property_id: propertiesObj.id,
                unit_id: unitsObj.id,
                unit_code: input.unit_code,
                createdBy: event.user.id
            };
            validateTenantSignUp(tenantObj);
            let obj = await Tenants.create(tenantObj);
            plainTextObj = obj.get({plain: true});

            unitsObj.unit_status = 'NotAvailable';
            await unitsObj.save();
        return {
            statusCode: 200, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify(plainTextObj),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Could not create the Users.'}),
        };
    }
};
const getOne = async (event) => {
    try {
        const {Users, Op} = await connectToDatabase();
        const pathParams = event.pathParameters || event.queryStringParameters;
        authorizeGetOne(event.user);
        const user = await Users.findOne({where: {id: pathParams.id, is_deleted: {[Op.not]: true}}, raw: true});
        if (!user) throw new HTTPError(404, `User with id: ${pathParams.id} was not found`);
        return {
            statusCode: 200, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify(user),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Could not fetch the Users.'}),
        };
    }
};
const getAll = async (event) => {
    try {
        let header = event.headers;
        const {Users, Op} = await connectToDatabase();
        const query = event.queryStringParameters || {};
        if (header.offset) query.offset = parseInt(header.offset, 10);
        if (header.limit) query.limit = parseInt(header.limit, 10);
        if (query.where) query.where = JSON.parse(query.where);
        if (!query.where) {
            query.where = {};
        }
        query.where.is_deleted = {[Op.not]: true};
        query.order = [['createdAt', 'DESC']];
        query.raw = true;

        authorizeGetAll(event.user);
        const user = await Users.findAll(query);
        return {
            statusCode: 200, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify(user),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Could not fetch the Users.'}),
        };
    }
};
const destroy = async (event) => {
    try {
        const {Users, Op} = await connectToDatabase();
        authorizeDestroy(event.user);
        const pathParams = event.pathParameters || event.queryStringParameters;
        const usersObj = await Users.findOne({where: {id: pathParams.id, is_deleted: {[Op.not]: true}}});
        if (!usersObj) throw new HTTPError(404, `User with id: ${pathParams.id} was not found`);
        usersObj.is_deleted = true;
        usersObj.updatedBy = event.user.id;
        await usersObj.save();
        return {
            statusCode: 200, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify(usersObj),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Could destroy fetch the Users.'}),
        };
    }
};
const update = async (event) => {
    try {
        const input = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;

        const pathParams = event.pathParameters || event.queryStringParameters;
        if (!pathParams.id) throw new HTTPError(404, `Users for this ${pathParams.id} was not found`);
        const {Users, Op, Maintenance} = await connectToDatabase();
        const usersObj = await Users.findOne({where: {id: pathParams.id}});
        if (!usersObj) throw new HTTPError(400, `Users for this ${pathParams.id} was not found`);
        if (input.password) {
            input.password = await usersObj.generateNewPassword(input.password);
        } else {
            input.password = usersObj.password;
        }
        input.updatedBy = event.user.id;
        const userstb = Object.assign(usersObj, input);
        const updateUsers = await userstb.save();
        const plainText = updateUsers.get({plain: true});
        if(event.user.role == 'Maintenance'){
            const maintenanceObj = await Maintenance.findOne({where: {user_id:pathParams.id}});
            if(maintenanceObj?.id){
                const maintenanceDetails = Object.assign(maintenanceObj, {name:plainText.name, phone:plainText.phone_number, country_code:plainText.country_code});
                await maintenanceDetails.save();
            }
        }   
        return {
            statusCode: 200, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify(updateUsers),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500, headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            }, body: JSON.stringify({error: err.message || 'Could not Update the Users.'}),
        };
    }
};
//##up
// const db = require('../../models');  // Sequelize model access
// const User = db.Users;
// const { validateUpdateProfile } = require('./validation');

// exports.updateProfile = async (req, res) => {
//     try {
//         const userId = req.user.id;
//         const { phone, email } = req.body;

//         validateUpdateProfile({ phone, email });

//         await User.update(
//             { phone, email },
//             { where: { id: userId } }
//         );

//         return res.status(200).json({ message: 'Profile updated successfully' });

//     } catch (err) {
//         console.error('Error in updateProfile:', err);
//         if (err.statusCode) {
//             return res.status(err.statusCode).json({ message: err.message });
//         }
//         return res.status(500).json({ message: 'Internal server error' });
//     }
// };


module.exports.signup = signup;
module.exports.login = login;
module.exports.getOne = middy(getOne).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.getAll = getAll;
module.exports.forgetPassword = forgetPassword;
module.exports.resetPassword = middy(resetPassword).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.otpVerification = otpVerification;
module.exports.otpDestroy = middy(otpDestroy).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.create = middy(create).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.destroy = middy(destroy).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.update = middy(update).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.sessionData = middy(sessionData).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());