const {HTTPError} = require('../../utils/httpResp');

const Owner = ['Owner'];
const Tenant = ['Tenant'];
const roleCollection = ['Owner', 'Tenant'];

exports.authorizeCreate = function (user) {
    if (!roleCollection.includes(user.role)) {
        throw new HTTPError(403, 'forbidden');
    }
};
exports.authorizeGetOne = function (user) {
    if (!roleCollection.includes(user.role)) {
        throw new HTTPError(403, 'forbidden');
    }
};
exports.authorizeGetAll = function (user) {
    if (!Owner.includes(user.role)) {
        throw new HTTPError(403, 'forbidden');
    }
};
exports.authorizeUpdate = function (user) {
    if (!roleCollection.includes(user.role)) {
        throw new HTTPError(403, 'forbidden');
    }
};

exports.authorizeDestroy = function (user) {
    if (!Owner.includes(user.role)) {
        throw new HTTPError(403, 'forbidden');
    }
};  