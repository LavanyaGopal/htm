const bcrypt = require('bcryptjs');
module.exports = (sequelize, type) => {
    const User = sequelize.define('Users', {
            id: {
                type: type.STRING,
                primaryKey: true,
            },
            name: type.STRING,
            email: type.STRING,
            country_code: {
                type: type.STRING,
                defaultValue: "+91",
            },
            phone: type.STRING,
            device_token: type.TEXT,
            password: type.STRING,
            role: type.STRING,//Tenants,Owner
            otp_code: type.STRING,//Tenants,Owner,superAdmin
            is_temporary_password: type.BOOLEAN,
            is_email_verified: type.BOOLEAN,
            is_phone_verified: type.BOOLEAN,
            is_admin: type.BOOLEAN,
            last_login_ts: type.DATE,
            createdBy: type.STRING,
            updatedBy: type.STRING,
            is_deleted: type.BOOLEAN,
            profile_image: type.STRING,
        }, {
            hooks: {
                async beforeCreate(user) {
                    const salt = await bcrypt.genSalt(); // whatever number you want
                    user.password = await bcrypt.hash(user.password, salt);
                },
            },
        },
    );

    User.prototype.validPassword = async function (password) {
        return await bcrypt.compare(password, this.password);
    };
    User.prototype.generateNewPassword = async function (password) {
        const salt = await bcrypt.genSalt(); // whatever number you want
        return await bcrypt.hash(password, salt);
    };

    return User;
};

