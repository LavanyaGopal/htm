const Validator = require('validatorjs');
const commonPassword = require('common-password-checker');
const {HTTPError} = require('../../utils/httpResp');
const connectToDatabase = require('../../db');

exports.validateSignup = (data) => {
    const rules = {
        name: 'required|min:4|max:64',
        email: 'email|min:4|max:64',
        phone: 'required',//it must be a number
        role: 'required',
        otp_code: 'required',
        password: 'required|min:4|max:64',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }

    const hasUpperCase = /[A-Z]/.test(data.password);
    const hasLowerCase = /[a-z]/.test(data.password);
    const hasNumbers = /\d/.test(data.password);
    const hasNonalphas = /\W/.test(data.password);
    const hasTripple = /(.)\1\1/.test(data.password);


    if (!hasUpperCase && !hasLowerCase) throw new HTTPError(400, 'Password must contain one alphabetic character');
    if (!hasNumbers && !hasNonalphas) throw new HTTPError(400, 'Password must contain one numeric or special character');
    if (hasTripple) throw new HTTPError(400, 'Password must not have consecutive characters');
    if (commonPassword(data.password)) throw new HTTPError(400, 'Password must not be a common or easily guessable password');

    const validRoles = ['Owner', 'Tenant', 'superAdmin',''];
    if (!validRoles.includes(data.role)) throw new HTTPError(400, 'Invalid role');
};
exports.validateCreateUser = (data) => {
    const rules = {
        name: 'required|min:4|max:64',
        email: 'email|min:4|max:64',
        phone: 'numeric|digits:10|required',
        role: 'required',
        password: 'required|min:4|max:64',
    };
    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
    const hasUpperCase = /[A-Z]/.test(data.password);
    const hasLowerCase = /[a-z]/.test(data.password);
    const hasNumbers = /\d/.test(data.password);
    const hasNonalphas = /\W/.test(data.password);
    const hasTripple = /(.)\1\1/.test(data.password);


    if (!hasUpperCase && !hasLowerCase) throw new HTTPError(400, 'Password must contain one alphabetic character');
    if (!hasNumbers && !hasNonalphas) throw new HTTPError(400, 'Password must contain one numeric or special character');
    if (hasTripple) throw new HTTPError(400, 'Password must not have consecutive characters');
    if (commonPassword(data.password)) throw new HTTPError(400, 'Password must not be a common or easily guessable password');

    const validRoles = ['Tenants'];
    if (!validRoles.includes(data.role)) throw new HTTPError(400, 'Invalid role');
};
exports.validateLogin = (data) => {
    const rules = {
        email: 'email',
        password: 'required|min:4|max:32',
    };
    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
};
exports.validateForgetPassword = (data) => {
    const rules = {
        phone: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
};
exports.validateResetPassword = (data) => {
    const rules = {
        new_password: 'required|min:4|max:64',
    };
    const validation = new Validator(data, rules);

    const hasUpperCase = /[A-Z]/.test(data.new_password);
    const hasLowerCase = /[a-z]/.test(data.new_password);
    const hasNumbers = /\d/.test(data.new_password);
    const hasNonalphas = /\W/.test(data.new_password);
    const hasTripple = /(.)\1\1/.test(data.new_password);
    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }

    if (!hasUpperCase && !hasLowerCase) throw new HTTPError(400, 'Password must contain one alphabetic character');
    if (!hasNumbers && !hasNonalphas) throw new HTTPError(400, 'Password must contain one numeric or special character');
    if (hasTripple) throw new HTTPError(400, 'Password must not have consecutive characters');
    if (commonPassword(data.new_password)) throw new HTTPError(400, 'Password must not be a common or easily guessable password');
};
exports.validateOtp = (data) => {
    const rules = {
        otp_code: 'required|size:6',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
}
exports.validateTenantSignUp = async (data) => {
    const rules = {
        id: 'required',
        joining_date: 'required',
        user_id: 'required',
        property_id: 'required',
        unit_id: 'required',
        unit_code: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        const {Users, Op} = await connectToDatabase();
        await Users.destroy({where: {id: data.user_id}});
        throw new HTTPError(400, validation.errors.all());
    }
}
//##up
// exports.validateUpdateProfile = (data) => {
//     const rules = {
//         email: 'required|email',
//         phone: 'required|numeric|digits:10',
//     };

//     const validation = new Validator(data, rules);

//     if (validation.fails()) {
//         throw new HTTPError(400, validation.errors.all());
//     }
// };