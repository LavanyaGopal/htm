const Validator = require('validatorjs');
const {HTTPError} = require('../../utils/httpResp');


exports.validateCreateProperties = function (data) {
    const rules = {
        user_id: 'required',
        property_name: 'required',
        total_units: 'required',
        street: 'required|min:4|max:300',
        city: 'required|min:4|max:64',
        state: 'required|min:4|max:64',
        zip_code: 'required',
        property_code: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
};
exports.validateDropdown = (data) => {
    const rules = {
        user_id: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
}
exports.validateGetOne = function (data) {
    const rules = {
        id: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
};
exports.validateUpdate = function (data) {
    const rules = {
        id: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
};
exports.validateDestroy = function (data) {
    const rules = {
        id: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
};
