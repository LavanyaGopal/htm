module.exports = (sequelize, type) => sequelize.define('Property', {
    id: {
        type: type.STRING,
        primaryKey: true,
    },
    user_id: type.STRING,
    property_name: type.STRING,
    total_units: type.INTEGER,
    street: type.TEXT,
    city: type.STRING,
    state: type.STRING,
    zip_code: type.STRING,
    is_deleted: type.BOOLEAN,
    property_code: {
        type: type.STRING,
        allowNull: false,
        //unique: true
    },  //Auto Generate
    createdBy: type.STRING,
    updatedBy: type.STRING,
});