const uuid = require('uuid');
const middy = require('@middy/core');
const doNotWaitForEmptyEventLoop = require('@middy/do-not-wait-for-empty-event-loop');
const connectToDatabase = require('../../db');
const {HTTPError} = require('../../utils/httpResp');
const {generateRandomString} = require('../../utils/randomStringGenerator');
const authMiddleware = require('../../authMiddleware');
const {
    validateCreateProperties,
    validateDropdown,
    validateGetOne,
    validateUpdate,
    validateDestroy
} = require('./validation');

const create = async (event) => {
    try {
        let id;
        const input = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        let propertyCode = generateRandomString(8);
        const dataObject = Object.assign(input, {
            id: id || uuid.v4(),
            property_code: propertyCode,
            user_id: event.user.id,
            createdBy: event.user.id
        });
        validateCreateProperties(dataObject);
        const {Properties} = await connectToDatabase();
        const PropertiesObj = await Properties.create(dataObject);
        const plainText = PropertiesObj.get({plain: true});
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify(plainText),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not create the owner properties.'}),
        };
    }
};
const getAll = async (event) => {
    try {
        let header = event.headers;
        const {Properties, Op} = await connectToDatabase();
        const query = event.pathParameters || event.queryStringParameters || {};
        if (header.offset) query.offset = parseInt(header.offset, 10);
        if (header.limit) query.limit = parseInt(header.limit, 10);
        if (query.where) query.where = JSON.parse(query.where);
        if (!query.where) {
            query.where = {};
        }
        query.where.user_id = event.user.id;
        query.where.is_deleted = {[Op.not]: true};
        query.order = [
            ['createdAt', 'DESC'],
        ];
        query.logging = console.log;
        query.raw = true;
        const propertiesObj = await Properties.findAll(query);
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify(propertiesObj),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not get properties Deatails.'}),
        };
    }
};
const getOne = async (event) => {
    try {
        const input = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        const pathParams = event.pathParameters || event.queryStringParameters;
        validateGetOne(pathParams);
        const {Properties, Op} = await connectToDatabase();
        const propertiesObj = await Properties.findOne({
            where: {id: pathParams.id, is_deleted: {[Op.not]: true}},
            logging: console.log
        });
        if (!propertiesObj) throw new HTTPError(404, `Properties for this ${pathParams.id} was not found`);
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify(propertiesObj),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not get properties Deatails.'}),
        };
    }
};
const update = async (event) => {
    try {
        const input = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        const pathParams = event.pathParameters || event.queryStringParameters;
        validateUpdate(pathParams);
        const {Properties, Op} = await connectToDatabase();
        const propertiesObj = await Properties.findOne({where: {id: pathParams.id, is_deleted: {[Op.not]: true}}});
        if (!propertiesObj) throw new HTTPError(404, `Properties for this ${pathParams.id} was not found`);
        input.updatedBy = event.user.id;
        const propertiestb = Object.assign(propertiesObj, input);
        console.log(propertiestb);
        await propertiestb.save();
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify(propertiestb),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not get properties Deatails.'}),
        };
    }
};
const destroy = async (event) => {
    try {
        const pathParams = event.pathParameters || event.queryStringParameters;
        validateDestroy(pathParams);
        const {Properties, Op} = await connectToDatabase();
        const propertiesObj = await Properties.findOne({where: {id: pathParams.id, is_deleted: {[Op.not]: true}}});
        if (!propertiesObj) throw new HTTPError(404, `Properties for this ${pathParams.id} was not found`);
        propertiesObj.is_deleted = true;
        propertiesObj.updatedBy = event.user.id;
        await propertiesObj.save();
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({
                status: 'ok',
                message: 'Successfully Properties Data removed',
            }),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not Delete properties Deatails.'}),
        };
    }
};
const dropdown = async (event) => {
    try {
        let header = event.headers;
        const {Properties, Op, Users} = await connectToDatabase();
        const query = event.pathParameters || event.queryStringParameters || {};
        if (header.offset) query.offset = parseInt(header.offset, 10);
        if (header.limit) query.limit = parseInt(header.limit, 10);
        if (query.where) query.where = JSON.parse(query.where);
        if (!query.where) {
            query.where = {};
        }
        query.where.user_id = event.user.id;
        query.where.is_deleted = {[Op.not]: true};
        query.order = [
            ['createdAt', 'DESC'],
        ];
        query.logging = console.log;
        query.raw = true;
        const propertiesObj = await Properties.findAll(query);
        for (let i = 0; i < propertiesObj.length; i++) {
            const ownerObj = await Users.findOne({where: {id: propertiesObj[i].user_id, is_deleted: {[Op.not]: true}}});
            if (!ownerObj) {
                propertiesObj.splice(i, 1);
                i--;
                continue;
            }
            propertiesObj[i].owner_name = ownerObj.name;
            propertiesObj[i].owner_email = ownerObj.email;
            propertiesObj[i].owner_phone = ownerObj.phone;
            propertiesObj[i].owner_country_code = ownerObj.country_code;
            propertiesObj[i].owner_role = ownerObj.role;
            const createdUserObj = await Users.findOne({
                where: {
                    id: propertiesObj[i].createdBy,
                    is_deleted: {[Op.not]: true}
                }
            });
            if (!createdUserObj) {
                propertiesObj.splice(i, 1);
                i--;
                continue;
            }
            propertiesObj[i].created_by = createdUserObj.name;
        }
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify(propertiesObj),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not get properties Deatails.'}),
        };
    }
};
module.exports.create = middy(create).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.getAll = getAll;
module.exports.getOne = middy(getOne).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.update = middy(update).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.destroy = middy(destroy).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.dropdown = dropdown;
