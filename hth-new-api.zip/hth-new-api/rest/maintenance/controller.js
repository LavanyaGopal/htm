const uuid = require('uuid');
const middy = require('@middy/core');
const doNotWaitForEmptyEventLoop = require('@middy/do-not-wait-for-empty-event-loop');
const connectToDatabase = require('../../db');
const {HTTPError} = require('../../utils/httpResp');
const authMiddleware = require('../../authMiddleware');
const {generateRandomString} = require('../../utils/randomStringGenerator');
const {validateCreateMaintenance, validateGetOne, validateUpdate, validateDestroy, validateCreateMaintenanceUser} = require('./validation');
const create = async (event) => {
    try {
        const {Maintenance, Op, Properties, Users} = await connectToDatabase();
        let id;
        const input = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        /* Create User details in User's table for login credentials. */

        let phone = input.phone_number.startsWith('+91') ? input.phone_number : '+91'+input.phone_number;
        let otp_code = generateRandomString(6);
        let role;
        let roleArr = ['Tenant','Owner'];
        if(!roleArr.includes(input.category_type)) role = 'Maintenance';
        
        let userObject = await Users.count({where: {phone, is_deleted: {[Op.not]: true}}});
        
        if (userObject) throw new HTTPError(400, `User with phone : ${phone} already exist`);

        let createMaintenanceUser = {
            id: uuid.v4(),
            name: input.name,
            phone,
            password: input?.password || 'User@123!',
            role: role,
            otp_code,
            is_temporary_password: true,
            createdBy: event.user.id
        }
        validateCreateMaintenanceUser(createMaintenanceUser)
        /* Send Maintenance Deatils in Email */
        let userObj = await Users.create(createMaintenanceUser);
        let userPlainText = userObj.get({plain: true});
        if(!userObj) throw new HTTPError(400, `Could not create maintenance details.`);
        const dataObject = Object.assign(input, {
            id: id || uuid.v4(),
            owner_id: event.user.id,
            user_id: userPlainText.id,
            createdBy: event.user.id,
            phone_number : phone
        });
        validateCreateMaintenance(dataObject);
        const maintenanceObj = await Maintenance.create(dataObject);
        const plainText = maintenanceObj.get({plain: true});
        const propertiesObj = await Properties.findOne({
            where: {
                id: plainText.property_id,
                is_deleted: {[Op.not]: true}
            }, raw: true
        });
        plainText.property_name = propertiesObj.property_name;
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify(plainText),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not create the Maintenance Deatails.'}),
        };
    }
};
const getOne = async (event) => {
    try {
        const {Maintenance, Op} = await connectToDatabase();
        const pathParams = event.pathParameters || event.queryStringParameters;
        const login_user_info = event.user;
        if(login_user_info && login_user_info.role == 'Tenant' && !login_user_info.property_id && !login_user_info.unit_id) 
        {
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'text/plain',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': true
                },
                body: JSON.stringify([]),
            };
        }
        validateGetOne(pathParams);
        const maintenance = await Maintenance.findOne({
            where: {id: pathParams.id, is_deleted: {[Op.not]: true}},
            raw: true
        });
        if (!maintenance) throw new HTTPError(404, `Maintenance user with id: ${pathParams.id} was not found`);
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify(maintenance),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not fetch the  Maintenance User.'}),
        };
    }
};
const getAll = async (event) => {
    try {
        const {Maintenance, Op, Users, Tenants, Properties} = await connectToDatabase();
        let id = event.user.id;
        const login_user_info = event.user;
        if(login_user_info && login_user_info.role == 'Tenant' && !login_user_info.property_id && !login_user_info.unit_id) 
        {
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'text/plain',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': true
                },
                body: JSON.stringify([]),
            };
        }
        const usersOj = await Users.findOne({where: {id: event.user.id, is_deleted: {[Op.not]: true}}, raw: true});
        if (event.user.role == 'Tenant') {
            const TenantsObj = await Tenants.findOne({
                where: {user_id: usersOj.id, is_deleted: {[Op.not]: true}},
                logging: console.log,
                raw: true
            });
            id = TenantsObj.property_id;
        }

        let header = event.headers;
        const query = event.pathParameters || event.queryStringParameters || {};
        if (header.offset) query.offset = parseInt(header.offset, 10);
        if (header.limit) query.limit = parseInt(header.limit, 10);
        if (query.where) query.where = JSON.parse(query.where);
        if (!query.where) {
            query.where = {};
        }
        query.where.is_deleted = {[Op.not]: true};
        if (event.user.role == 'Owner') {
            query.where.owner_id = id;
        }
        if (event.user.role == 'Tenant') {
            query.where.property_id = id;
        }
        if(event.user.role == 'Maintenance'){
            query.where.user_id = event.user.id
        }
        query.order = [
            ['createdAt', 'DESC'],
        ];
        query.logging = console.log;
        query.raw = true;
        const maintenanceObj = await Maintenance.findAll(query);
        if (maintenanceObj.length != 0) {
            for (let i = 0; i < maintenanceObj.length; i++) {
                const propertiesObj = await Properties.findOne({
                    where: {
                        id: maintenanceObj[i].property_id,
                        is_deleted: {[Op.not]: true}
                    }, raw: true
                });
                maintenanceObj[i].property_name = propertiesObj.property_name;
            }
        }

        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify(maintenanceObj),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not fetch the  Maintenance User\'s Deatails.'}),
        };
    }
};
const update = async (event) => {
    try {
        const input = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        const pathParams = event.pathParameters || event.queryStringParameters;
        const login_user_info = event.user;
        if(login_user_info && login_user_info.role == 'Tenant' && !login_user_info.property_id && !login_user_info.unit_id) 
        {
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'text/plain',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': true
                },
                body: JSON.stringify([]),
            };
        }
        validateUpdate(pathParams);
        const {Maintenance, Op, Users} = await connectToDatabase();
        const MaintenanceObj = await Maintenance.findOne({where: {id: pathParams.id, is_deleted: {[Op.not]: true}}});
        if (!Maintenance) throw new HTTPError(404, `Cannot find Maintenance Deatails with id ${pathParams.id}`);
        input.updatedBy = event.user.id;
        const maintenancetb = Object.assign(MaintenanceObj, input);
        const updateMaintenance = await maintenancetb.save();
        const plainText = updateMaintenance.get({plain: true});
        if(plainText.user_id){
            const usersObj = await Users.findOne({where:{id:plainText.user_id,is_deleted:{[Op.not]:true}}});
            if(usersObj){
                const usersdetails = Object.assign(usersObj, {name:plainText.name, phone:plainText.phone_number, country_code:plainText.country_code});
                await usersdetails.save();
            }
        }
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify(updateMaintenance),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not Update the Maintenance.'}),
        };
    }
};
const destroy = async (event) => {
    try {
        const {Maintenance, Op, Users} = await connectToDatabase();
        const pathParams = event.pathParameters || event.queryStringParameters;
        const login_user_info = event.user;
        if(login_user_info && login_user_info.role == 'Tenant' && !login_user_info.property_id && !login_user_info.unit_id) 
        {
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'text/plain',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': true
                },
                body: JSON.stringify([]),
            };
        }
        validateDestroy(pathParams);
        const maintenanceObj = await Maintenance.findOne({where: {id: pathParams.id, is_deleted: {[Op.not]: true}}});
        if (!maintenanceObj) throw new HTTPError(404, `Cannot find Maintenance Deatails with id ${pathParams.id}`);
        maintenanceObj.is_deleted = true;
        maintenanceObj.updatedBy = event.user.id;
        await maintenanceObj.save();
        if(maintenanceObj.user_id){
            const usersObj = await Users.findOne({where:{id:maintenanceObj.user_id}});
            if(usersObj?.id){
                usersObj.is_deleted = true;
                usersObj.updatedBy = event.user.id;
                await usersObj.save();
            }
        }
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({
                status: 'ok',
                message: 'Maintenance Data removed Successfully',
            }),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not Delete the Maintenance.'}),
        };
    }
}
const dropdown = async (event) => {
    try {
        const {Maintenance, Op, Users, Tenants, Properties} = await connectToDatabase();
        let id = event.user.id;
        const login_user_info = event.user;
        if(login_user_info && login_user_info.role == 'Tenant' && !login_user_info.property_id && !login_user_info.unit_id) 
        {
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'text/plain',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': true
                },
                body: JSON.stringify([]),
            };
        }
        const usersOj = await Users.findOne({where: {id: event.user.id, is_deleted: {[Op.not]: true}}, raw: true});
        if (event.user.role == 'Tenant') {
            const TenantsObj = await Tenants.findOne({
                where: {user_id: usersOj.id, is_deleted: {[Op.not]: true}},
                logging: console.log,
                raw: true
            });
            id = TenantsObj.property_id;
            console.log('--Tenant--');
            console.log(TenantsObj);
        }
        let header = event.headers;
        const query = event.pathParameters || event.queryStringParameters || {};
        if (header.offset) query.offset = parseInt(header.offset, 10);
        if (header.limit) query.limit = parseInt(header.limit, 10);
        if (query.where) query.where = JSON.parse(query.where);
        if (!query.where) {
            query.where = {};
        }
        query.where.is_deleted = {[Op.not]: true};
        if (event.user.role == 'Owner') {
            query.where.owner_id = id;
        }
        if (event.user.role == 'Tenant') {
            query.where.property_id = id;
        }
        query.order = [
            ['createdAt', 'DESC'],
        ];
        query.logging = console.log;
        query.raw = true;
        const maintenanceObj = await Maintenance.findAll(query);
        for (let i = 0; i < maintenanceObj.length; i++) {
            const propertiesObj = await Properties.findOne({
                where: {
                    id: maintenanceObj[i].property_id,
                    is_deleted: {[Op.not]: true}
                }, raw: true
            });
            maintenanceObj[i].property_name = propertiesObj.property_name;
            maintenanceObj[i].total_units = propertiesObj.property_name;
            maintenanceObj[i].street = propertiesObj.property_name;
            maintenanceObj[i].city = propertiesObj.property_name;
            maintenanceObj[i].state = propertiesObj.property_name;
            const ownerObj = await Users.findOne({
                where: {
                    id: maintenanceObj[i].owner_id,
                    is_deleted: {[Op.not]: true}
                }
            });
            maintenanceObj[i].property_owner_name = ownerObj.name;
            maintenanceObj[i].property_owner_email = ownerObj.email;
            maintenanceObj[i].property_owner_phone = ownerObj.phone;
            maintenanceObj[i].property_owner_country_code = ownerObj.country_code;
            maintenanceObj[i].property_owner_role = ownerObj.role;
        }

        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify(maintenanceObj),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not fetch the  Maintenance User\'s Deatails.'}),
        };
    }
};
module.exports.create = middy(create).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.getOne = middy(getOne).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.getAll = getAll;
module.exports.update = middy(update).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.destroy = middy(destroy).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.dropdown = dropdown;