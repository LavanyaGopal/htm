module.exports = (sequelize, type) => sequelize.define('Maintenance', {
    id: {
        type: type.STRING,
        primaryKey: true,
    },
    owner_id: type.STRING,
    user_id: type.STRING,
    property_id: type.STRING,
    category_type: type.STRING,
    name: type.STRING,
    phone_number: type.STRING,
    country_code: {
        type: type.STRING,
        defaultValue: "+91",
    },
    street: type.STRING,
    city: type.STRING,
    state: type.STRING,
    zip_code: type.STRING,
    is_deleted: type.BOOLEAN,
    createdBy: type.STRING,
    updatedBy: type.STRING,
});