const Validator = require('validatorjs');
const {HTTPError} = require('../../utils/httpResp');


exports.validateCreateMaintenance = function (data) {
    const rules = {
        user_id: 'required',
        owner_id: 'required',
        property_id: 'required',
        name: 'required',
        phone_number: 'required',
        category_type: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
};
exports.validateCreateMaintenanceUser = function (data) {
    const rules = {
        name:'required',
        phone:'required',
        password:'required',
        role:'required',
        otp_code:'required',
        is_temporary_password :'required',
        createdBy :'required'
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
};

exports.validateGetOne = function (data) {
    const rules = {
        id: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
};
exports.validateUpdate = function (data) {
    const rules = {
        id: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
};
exports.validateDestroy = function (data) {
    const rules = {
        id: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
};