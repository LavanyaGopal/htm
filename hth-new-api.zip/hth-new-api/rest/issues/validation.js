const Validator = require('validatorjs');
const {HTTPError} = require('../../utils/httpResp');


exports.validateCreateIssues = function (data) {
    const rules = {
        maintenance_id: 'required',
        tenant_id: 'required',
        property_id: 'required',
        user_id: 'required',
        message_box: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
};
exports.validateGetOne = function (data) {
    const rules = {
        id: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
};
exports.validateUpdate = function (data) {
    const rules = {
        id: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
};
exports.validateDestroy = function (data) {
    const rules = {
        id: 'required',
    };

    const validation = new Validator(data, rules);

    if (validation.fails()) {
        throw new HTTPError(400, validation.errors.all());
    }
};

