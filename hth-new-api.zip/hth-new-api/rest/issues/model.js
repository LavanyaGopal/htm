module.exports = (sequelize, type) => sequelize.define('Issue', {
    id: {
        type: type.STRING,
        primaryKey: true,
    },
    user_id: type.STRING,
    owner_id: type.STRING,
    property_id: type.STRING,
    tenant_id: type.STRING,
    maintenance_id: type.STRING,
    message_box: type.TEXT,
    issue_image: type.TEXT,
    resolved_date: type.DATEONLY,
    issue_raised: type.DATEONLY,
    resolved_image: type.TEXT,
    comments: type.TEXT, // Resolved comments here
    status: type.TEXT,  // Pending ,Resolved
    amount_charged: type.TEXT,
    is_deleted: type.BOOLEAN,
    createdBy: type.STRING,
    updatedBy: type.STRING,
});