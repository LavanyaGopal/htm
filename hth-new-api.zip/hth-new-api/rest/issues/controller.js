const uuid = require('uuid');
const middy = require('@middy/core');
const doNotWaitForEmptyEventLoop = require('@middy/do-not-wait-for-empty-event-loop');
const connectToDatabase = require('../../db');
const {HTTPError} = require('../../utils/httpResp');
const authMiddleware = require('../../authMiddleware');
const {validateCreateIssues, validateGetOne, validateUpdate, validateDestroy} = require('./validation');
const {pushNotification} = require('../../utils/sendPushNotification');
const {NotificationStamp} = require('../../utils/timeStamp');

const FCM = require("fcm-node");
const serverKey = process.env.FCM_SERVER_KEY; //put your server key here
const fcm = new FCM(serverKey);

const create = async (event) => {
    try {
        const {Issues, Maintenance, Properties, Tenants, Users, Op, Units, Notification} = await connectToDatabase();
        let id;
        const login_user_info = event.user;
        if(login_user_info && login_user_info.role == 'Tenant' && !login_user_info.property_id && !login_user_info.unit_id) 
        {
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'text/plain',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': true
                },
                body: JSON.stringify([]),
            };
        }
        const input = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        const userObj = await Users.findOne({
            where: {id: event.user.id, is_deleted: {[Op.not]: true}, role: 'Tenant'},
            logging: console.log,
            raw: true
        });
        const tenantObj = await Tenants.findOne({
            where: {user_id: userObj.id, is_deleted: {[Op.not]: true}},
            logging: console.log,
            raw: true
        });
        const ownerProperty = await Properties.findOne({
            where: {
                id: tenantObj.property_id,
                is_deleted: {[Op.not]: true}
            }, logging: console.log, raw: true
        });
        const unitsObj = await Units.findOne({
            where: {
                user_id: ownerProperty.user_id,
                property_id: ownerProperty.id,
                is_deleted: {[Op.not]: true}
            }, logging: console.log, raw: true
        });
        const getOwnerObj = await Users.findOne({
            where: {id: ownerProperty.user_id, is_deleted: {[Op.not]: true}},
            logging: console.log,
            raw: true
        });

        if (!tenantObj && !userObj) throw new HTTPError(400, 'Invalid Tenant ID');
        const dataObject = Object.assign(input, {
            id: id || uuid.v4(),
            user_id: userObj.id,
            tenant_id: tenantObj.id,
            createdBy: event.user.id,
            property_id: tenantObj.property_id,
            owner_id: getOwnerObj.id
        });
        validateCreateIssues(dataObject);
        const issuesObj = await Issues.create(dataObject);
        const plainText = issuesObj.get({plain: true});
        const maintenanceObj = await Maintenance.findOne({
            where: {
                id: plainText.maintenance_id,
                is_deleted: {[Op.not]: true}
            }, raw: true
        });
        const propertiesObj = await Properties.findOne({
            where: {
                id: plainText.property_id,
                is_deleted: {[Op.not]: true}
            }, raw: true
        });
        plainText.property_name = propertiesObj.property_name;
        plainText.unit_name = unitsObj.unit_name;
        plainText.unid_id = unitsObj.id;
        plainText.total_units = propertiesObj.total_units;
        plainText.category_type = maintenanceObj.category_type;
        plainText.maintenance_name = maintenanceObj.maintenance_name;
        plainText.phone_number = maintenanceObj.phone_number;

        const tenantNotification = {
            id: uuid.v4(), user_id: event.user.id, user_role: event.user.role, createdBy: event.user.id,
        };


        const TenantAndroidID = userObj.device_token || '';
        const tenantTitle = `${propertiesObj.property_name}: You have created an issue with the Category ${plainText.category_type}`;
        const tenantMessageBody = `${plainText.message_box}.`;

        tenantNotification.notification_type = 'Issue';
        tenantNotification.notification_type_id = plainText.id;
        tenantNotification.property_name = propertiesObj.property_name;
        tenantNotification.unit_name = unitsObj.unit_name;
        tenantNotification.title = tenantTitle;
        tenantNotification.message = tenantMessageBody;
        if (TenantAndroidID) {
            tenantNotification.device_token = TenantAndroidID;
        }

        await Notification.create(tenantNotification);


        if (userObj.device_token) {

            console.log('Inside push notification');
            console.log(' TenantAndroidID ' + TenantAndroidID);
            console.log(' tenantTitle ' + tenantTitle);
            console.log(' tenantMessageBody ' + tenantMessageBody);
            console.log(' serverKey ' + serverKey);
            console.log(FCM);
            console.log("^^^^^^^^^^^^^^^^^^^");
            /* const res = await pushNotification(OwnerAndroidID,ownerTitle,ownerMessageBody);
             console.log(res); */

            var message = {
                to: TenantAndroidID,
                notification: {
                    title: tenantTitle,
                    body: tenantMessageBody,
                },
            };

            let response = await new Promise(function (resolve, reject) {
                fcm.send(message, function (err, response) {
                    if (err) {
                        console.log('From pUsh notification');
                        console.log(err);
                        reject(err);
                    } else {
                        console.log(response);
                        resolve(response);
                    }
                });
            });


            const res = await pushNotification(TenantAndroidID, tenantTitle, tenantMessageBody);
            console.log(res);
        }


        const ownernotification = {
            id: uuid.v4(), user_id: getOwnerObj.id, user_role: getOwnerObj.role, createdBy: event.user.id,
        };

        const OwnerAndroidID = getOwnerObj.device_token || '';
        const ownerTitle = `${propertiesObj.property_name}: Tenant ${userObj.name} at unit ${unitsObj.unit_name} has created an issue with the Category ${plainText.category_type}`;
        const ownerMessageBody = `${plainText.message_box}.`;

        ownernotification.notification_type = 'Issue';
        ownernotification.notification_type_id = plainText.id;

        ownernotification.property_name = propertiesObj.property_name;
        ownernotification.unit_name = unitsObj.unit_name;
        ownernotification.title = ownerTitle;
        ownernotification.message = ownerMessageBody;
        if (OwnerAndroidID) {
            ownernotification.device_token = OwnerAndroidID;
        }

        await Notification.create(ownernotification);


        if (getOwnerObj.device_token) {
            console.log('Inside push notification');
            console.log(OwnerAndroidID);
            console.log(ownerTitle);
            console.log(ownerMessageBody);
            console.log(serverKey);
            console.log(FCM);
            console.log("^^^^^^^^^^^^^^^^^^^");
            /* const res = await pushNotification(OwnerAndroidID,ownerTitle,ownerMessageBody);
             console.log(res); */

            var message = {
                to: OwnerAndroidID,
                notification: {
                    title: ownerTitle,
                    body: ownerMessageBody,
                },
            };

            let response = await new Promise(function (resolve, reject) {
                fcm.send(message, function (err, response) {
                    if (err) {
                        console.log('From pUsh notification');
                        console.log(err);
                        reject(err);
                    } else {
                        console.log(response);
                        resolve(response);
                    }
                });
            });

        }


        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify(plainText),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not create the Issues Deatails.'}),
        };
    }
};
const getOne = async (event) => {
    try {
        const {Issues, Maintenance, Properties, Tenants, Users, Units, Op} = await connectToDatabase();
        const pathParams = event.pathParameters || event.queryStringParameters;
        const login_user_info = event.user;
        if(login_user_info && login_user_info.role == 'Tenant' && !login_user_info.property_id && !login_user_info.unit_id) 
        {
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'text/plain',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': true
                },
                body: JSON.stringify([]),
            };
        }
        validateGetOne(pathParams);
        const issuesObj = await Issues.findOne({where: {id: pathParams.id, is_deleted: {[Op.not]: true}}, raw: true});
        if (!issuesObj) throw new HTTPError(404, `Issues with id: ${pathParams.id} was not found`);

        const userObj = await Users.findOne({
            where: {
                id: issuesObj.user_id,
                is_deleted: {[Op.not]: true},
                role: 'Tenant'
            }, logging: console.log, raw: true
        });
        const maintenanceObj = await Maintenance.findOne({
            where: {
                id: issuesObj.maintenance_id,
                is_deleted: {[Op.not]: true}
            }, raw: true
        });
        const propertiesObj = await Properties.findOne({
            where: {
                id: issuesObj.property_id,
                is_deleted: {[Op.not]: true}
            }, raw: true
        });
        const tenantObj = await Tenants.findOne({
            where: {user_id: userObj.id, is_deleted: {[Op.not]: true}},
            logging: console.log,
            raw: true
        });
        const ownerProperty = await Properties.findOne({
            where: {
                id: tenantObj.property_id,
                is_deleted: {[Op.not]: true}
            }, logging: console.log, raw: true
        });
        const unitsObj = await Units.findOne({
            where: {
                user_id: ownerProperty.user_id,
                property_id: ownerProperty.id,
                is_deleted: {[Op.not]: true}
            }, logging: console.log, raw: true
        });
        if(issuesObj?.updatedBy){
            const updatedUser = await Users.findOne({
                where: {id: issuesObj.updatedBy, is_deleted: {[Op.not]: true}},
                logging: console.log,
                raw: true
            });
            issuesObj.updatedBy = updatedUser.name;
        }


        issuesObj.property_name = propertiesObj.property_name;
        issuesObj.total_units = propertiesObj.total_units;
        issuesObj.category_type = maintenanceObj.category_type;
        issuesObj.maintenance_name = maintenanceObj.name;
        issuesObj.phone_number = maintenanceObj.phone_number;
        issuesObj.unit_name = unitsObj.unit_name;
        issuesObj.unid_id = unitsObj.id;

        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify(issuesObj),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not fetch the  Issues.'}),
        };
    }
};
const getAll = async (event) => {
    try {
        const {Issues, Maintenance, Properties, Tenants, Users, Op, Units} = await connectToDatabase();
        let id = event.user.id;
        const login_user_info = event.user;
        if(login_user_info && login_user_info.role == 'Tenant' && !login_user_info.property_id && !login_user_info.unit_id) 
        {
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'text/plain',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': true
                },
                body: JSON.stringify([]),
            };
        }
        let header = event.headers;
        const query = event.pathParameters || event.queryStringParameters || {};
        if (header.offset) query.offset = parseInt(header.offset, 10);
        if (header.limit) query.limit = parseInt(header.limit, 10);
        if (query.where) query.where = JSON.parse(query.where);
        if (!query.where) {
            query.where = {};
        }
        if (event.user.role === 'Owner') {
            console.log('Inside Owner');
            query.where.owner_id = id;
        }
        if (event.user.role === 'Tenant') {
            console.log('Inside Tenant');
            query.where.user_id = id;
        }
        if (event.user.role === 'Maintenance') {
            const maintenceUserInfo = await Maintenance.findOne({where:{user_id:event.user.id}});
            query.where.maintenance_id = maintenceUserInfo.id;
        }
        query.where.is_deleted = {[Op.not]: true};
        query.order = [
            ['createdAt', 'DESC'],
        ];
        query.logging = console.log;
        query.raw = true;
        const issuesObj = await Issues.findAll(query);
        for (let i = 0; i < issuesObj.length; i++) {
            const maintenanceObj = await Maintenance.findOne({
                where: {
                    id: issuesObj[i].maintenance_id,
                    is_deleted: {[Op.not]: true}
                }, raw: true
            });
            const propertiesObj = await Properties.findOne({
                where: {
                    id: issuesObj[i].property_id,
                    is_deleted: {[Op.not]: true}
                }, raw: true
            });

            const userObj = await Users.findOne({
                where: {
                    id: issuesObj[i].user_id,
                    is_deleted: {[Op.not]: true},
                    role: 'Tenant'
                }, logging: console.log, raw: true
            });

            const tenantObj = await Tenants.findOne({
                where: {user_id: userObj.id, is_deleted: {[Op.not]: true}},
                logging: console.log,
                raw: true
            });
            const ownerProperty = await Properties.findOne({
                where: {
                    id: tenantObj.property_id,
                    is_deleted: {[Op.not]: true}
                }, logging: console.log, raw: true
            });
            const unitsObj = await Units.findOne({
                where: {
                    user_id: ownerProperty.user_id,
                    property_id: ownerProperty.id,
                    is_deleted: {[Op.not]: true}
                }, logging: console.log, raw: true
            });
            if(issuesObj[i]?.updatedBy){
                const updatedUser = await Users.findOne({
                    where: {id: issuesObj[i].updatedBy, is_deleted: {[Op.not]: true}},
                    logging: console.log,
                    raw: true
                });
                issuesObj[i].updatedBy = updatedUser.name;
            }

            issuesObj[i].property_name = propertiesObj.property_name;
            issuesObj[i].total_units = propertiesObj.total_units;
            issuesObj[i].category_type = maintenanceObj.category_type;
            issuesObj[i].maintenance_name = maintenanceObj.name;
            issuesObj[i].phone_number = maintenanceObj.phone_number;
            issuesObj[i].unit_name = unitsObj.unit_name;
            issuesObj[i].unit_id = unitsObj.id;


        }
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify(issuesObj),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not fetch the  Issue\'s Deatails.'}),
        };
    }
};
const update = async (event) => {
    try {
        const input = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        const pathParams = event.pathParameters || event.queryStringParameters;
        const login_user_info = event.user;
        if(login_user_info && login_user_info.role == 'Tenant' && !login_user_info.property_id && !login_user_info.unit_id) 
        {
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'text/plain',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': true
                },
                body: JSON.stringify([]),
            };
        }
        validateUpdate(pathParams);
        const {Issues, Maintenance, Properties, Tenants, Users, Units, Op, Notification} = await connectToDatabase();
        const issuesObj = await Issues.findOne({where: {id: pathParams.id, is_deleted: {[Op.not]: true}}});
        if (!issuesObj) throw new HTTPError(404, `Cannot find Issues Deatails with id ${pathParams.id}`);
        input.updatedBy = event.user.id;
        const issuestb = Object.assign(issuesObj, input);
        console.log(issuestb);
        const updateIssues = await issuestb.save();
        const plainText = updateIssues.get({plain: true});

        const maintenanceObj = await Maintenance.findOne({
            where: {
                id: plainText.maintenance_id,
                is_deleted: {[Op.not]: true}
            }, raw: true
        });
        const propertiesObj = await Properties.findOne({
            where: {
                id: plainText.property_id,
                is_deleted: {[Op.not]: true}
            }, raw: true
        });

        const userObj = await Users.findOne({
            where: {
                id: plainText.user_id,
                is_deleted: {[Op.not]: true},
                role: 'Tenant'
            }, logging: console.log, raw: true
        });

        const tenantObj = await Tenants.findOne({
            where: {user_id: userObj.id, is_deleted: {[Op.not]: true}},
            logging: console.log,
            raw: true
        });
        const ownerProperty = await Properties.findOne({
            where: {
                id: tenantObj.property_id,
                is_deleted: {[Op.not]: true}
            }, logging: console.log, raw: true
        });
        const unitsObj = await Units.findOne({
            where: {
                user_id: ownerProperty.user_id,
                property_id: ownerProperty.id,
                is_deleted: {[Op.not]: true}
            }, logging: console.log, raw: true
        });
        const getOwnerObj = await Users.findOne({
            where: {id: ownerProperty.user_id, is_deleted: {[Op.not]: true}},
            logging: console.log,
            raw: true
        });
        const updatedUser = await Users.findOne({
            where: {id: plainText.updatedBy, is_deleted: {[Op.not]: true}},
            logging: console.log,
            raw: true
        });

        if (input.status == 'Resolved') {

            const tenantNotification = {
                id: uuid.v4(), user_id: userObj.id, user_role: userObj.role, createdBy: event.user.id,
            };


            const TenantAndroidID = userObj.device_token || '';
            const tenantTitle = `${ownerProperty.property_name}: Issue has been resolved with the Category ${maintenanceObj.category_type}.`;
            const tenantMessageBody = '';


            tenantNotification.notification_type = 'IssueResolved';
            tenantNotification.notification_type_id = plainText.id;
            tenantNotification.property_name = ownerProperty.property_name;
            tenantNotification.unit_name = unitsObj.unit_name;
            tenantNotification.title = tenantTitle;
            //tenantNotification.message = tenantMessageBody;
            if (TenantAndroidID) {
                tenantNotification.device_token = TenantAndroidID;
            }

            await Notification.create(tenantNotification);


            if (userObj.device_token) {
                await pushNotification(TenantAndroidID, tenantTitle, tenantMessageBody);
            }

            const ownernotification = {
                id: uuid.v4(), user_id: getOwnerObj.id, user_role: getOwnerObj.role, createdBy: event.user.id,
            };

            const OwnerAndroidID = getOwnerObj.device_token || '';
            const ownerTitle = `${ownerProperty.property_name}: Issue has been resolved for the unit ${unitsObj.unit_name} with the Category ${maintenanceObj.category_type}.`;
            const ownerMessageBody = '';

            ownernotification.notification_type = 'IssueResolved';
            ownernotification.notification_type_id = plainText.id;
            ownernotification.property_name = ownerProperty.property_name;
            ownernotification.unit_name = unitsObj.unit_name;
            ownernotification.title = ownerTitle;
            ownernotification.message = ownerMessageBody;
            if (OwnerAndroidID) {
                ownernotification.device_token = OwnerAndroidID;
            }

            await Notification.create(ownernotification);

            if (getOwnerObj.device_token) {
                await pushNotification(OwnerAndroidID, ownerTitle, ownerMessageBody);
            }
        }

        plainText.property_name = propertiesObj.property_name;
        plainText.total_units = propertiesObj.total_units;
        plainText.category_type = maintenanceObj.category_type;
        plainText.maintenance_name = maintenanceObj.name;
        plainText.phone_number = maintenanceObj.phone_number;
        plainText.unit_name = unitsObj.unit_name;
        plainText.unit_id = unitsObj.id;
        plainText.updatedBy = updatedUser?.name;
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify(updateIssues),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not Update the Issues.'}),
        };
    }
};
const destroy = async (event) => {
    try {
        const {Issues, Op} = await connectToDatabase();
        const pathParams = event.pathParameters || event.queryStringParameters;
        const login_user_info = event.user;
        if(login_user_info && login_user_info.role == 'Tenant' && !login_user_info.property_id && !login_user_info.unit_id) 
        {
            return {
                statusCode: 200,
                headers: {
                    'Content-Type': 'text/plain',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': true
                },
                body: JSON.stringify([]),
            };
        }
        validateDestroy(pathParams);
        const issuesObj = await Issues.findOne({where: {id: pathParams.id, is_deleted: {[Op.not]: true}}});
        if (!issuesObj) throw new HTTPError(404, `Issues with id: ${pathParams.id} was not found`);
        issuesObj.is_deleted = true;
        issuesObj.updatedBy = event.user.id;
        await issuesObj.save();
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({
                status: 'ok',
                message: 'Issues Data removed Successfully',
            }),
        };
    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not Delete the Issues.'}),
        };
    }
}

module.exports.create = middy(create).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.getOne = middy(getOne).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.getAll = getAll;
module.exports.update = middy(update).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());
module.exports.destroy = middy(destroy).use(authMiddleware()).use(doNotWaitForEmptyEventLoop());