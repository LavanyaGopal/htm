const {response} = require('express');
const FCM = require('fcm-node');
const serverKey = process.env.FCM_SERVER_KEY; //put your server key here
const fcm = new FCM(serverKey);

const sendFCMNotification = async (event) => {
    try {
        let bodyTemp = 'Bill is created for this month. Please pay before the due date. Thank you. - Mar 30, 2022 10.00AM';
        var message = {
            to: 'f-lUgf5nv5w:APA91bGXdqOD9awpgOXDsw2CiigrEh17eCqb491Btf1HBlvl3j38ihvZKW8clKo4oUxIedIRINRonClxUdUVkeyroiLDEfyUEul143QAxvUN6O9F_Oz-YapyclHcmKOHsn9UQE--Wv-C',
            notification: {
                title: 'You have created a Bill for the unit (1A)', //You have created a Bill for the ${unit_name}
                body: bodyTemp,
            }
            /* ,
            data: { //you can send only notification or only data(or include both)
                title: 'ok cdfsdsdfsd',
                body: '{"name" : "okg ooggle ogrlrl","product_id" : "123","final_price" : "0.00035"}'
            }
            */

        };


        let response = await new Promise(function (resolve, reject) {
            fcm.send(message, function (err, response) {
                if (err) {
                    reject(err);
                } else {
                    resolve(response);
                }
            });
        });


        /* let response = fcm.send(message, function (err, response) {
          if (err) {
            return err;
          } else {
            console.log(response);
            return response;
          }
        }); */

        response = JSON.parse(response);

        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify(response),
        };

    } catch (err) {
        console.log(err);
        return {
            statusCode: err.statusCode || 500,
            headers: {
                'Content-Type': 'text/plain',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify({error: err.message || 'Could not send notification to the Users.'}),
        };
    }
};

module.exports.sendFCMNotification = sendFCMNotification;