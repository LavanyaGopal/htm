
// format: Thu Jan 24 2019 08:10:09 GMT-0800 (Pacific Standard Time)
exports.fullTextTime = function () {
  return Date();
};

// format: 2019-01-24T16:12:02.781Z
exports.isoTime = function () {
  const date = new Date();
  return date.toISOString();
};

// format: 2019-01-24 16:12:33
exports.utcTime = function () {
  const date = new Date();
  return date.toISOString().replace(/T/, ' ').replace(/\..+/, ' - ');
};

// format: 1/24/2019 8:10:22a
exports.localTime = function () {
  const date = new Date();
  return date.toLocaleString().replace(/,/, '').replace(/ AM/, 'a - ').replace(/ PM/, 'p - ');
};

//format: May 1, 2022, 10:22:27 PM
exports.NotificationStamp = function () {
  const options = {  year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute : 'numeric' , second: 'numeric' };
  const today  = new Date();
  return today.toLocaleDateString("en-US", options);
  }