const FCM = require("fcm-node");
const serverKey = process.env.FCM_SERVER_KEY; //put your server key here
const fcm = new FCM(serverKey);
/* npm i --save-dev @types/fcm-node */
const pushNotification = async (andriodID, Title, Body) => {
  try {
    var message = {
      to: andriodID,
      notification: {
        title: Title,
        body: Body,
      },
    };

    let response = await new Promise(function (resolve, reject) {
        fcm.send(message, function (err, response) {
        if (err) {
          console.log('From pUsh notification');
          console.log(err);
          reject(err);
        } else {
          console.log(response);
          resolve(response);
        }
      });
    });
    return response;
  } catch (err) {
      console.log(err);
    return {
        statusCode: err.statusCode || 500,
        headers: {
          'Content-Type': 'text/plain',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Credentials': true
        },
        body: JSON.stringify({ error: err.message || 'Could not send notification to the Users.' }),
      };
  }
};

module.exports.pushNotification = pushNotification;
